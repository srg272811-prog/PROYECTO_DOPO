import java.util.ArrayList;

/**
 * Simula una máquina tragamonedas formada por varias ruedas.
 *
 * @author Santiago
 * @version 1.0
 */
public class SlotMachine
{
    private ArrayList<Wheel> wheels;
    private boolean visible;
    private boolean lastOperation;
    private Rectangle machineBody;
    private boolean jackpot;    

    public SlotMachine()
    {
        wheels = new ArrayList<Wheel>();
        visible = false;
        lastOperation = true;
        jackpot = false;
    
        machineBody = new Rectangle();
        machineBody.changeSize(300, 120);
        machineBody.changeColor("blue");
        machineBody.moveHorizontal(20);
        machineBody.moveVertical(100);
    }

    /**
     * Adiciona una nueva rueda en la posición indicada.
     * Las posiciones externas comienzan en 1.
     *
     * @param pos posición donde se agregará la rueda
     */
    public void addWheel(int pos)
    {
        Wheel newWheel = new Wheel();

        if (pos < 1)
        {
            pos = 1;
        }

        if (pos > wheels.size() + 1)
        {
            pos = wheels.size() + 1;
        }

        wheels.add(pos - 1, newWheel);
        organizeWheels();
        lastOperation = true;
    }

    /**
     * Elimina la rueda ubicada en la posición indicada.
     * Las posiciones externas comienzan en 1.
     *
     * @param pos posición de la rueda que se eliminará
     */
    public void delWheel(int pos)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas para eliminar.");
            lastOperation = false;
            return;
        }

        if (pos < 1)
        {
            pos = 1;
        }

        if (pos > wheels.size())
        {
            pos = wheels.size();
        }

        wheels.remove(pos - 1);
        organizeWheels();
        lastOperation = true;
    }

    /**
     * Indica si la última operación se realizó correctamente.
     *
     * @return true si la última operación fue exitosa
     */
    public boolean ok()
    {
        return lastOperation;
    }

    /**
     * Agrega un símbolo del color indicado a todas las ruedas.
     *
     * @param pos posición donde se agregará el símbolo
     * @param color color que identifica el símbolo
     */
    public void addSymbol(int pos, String color)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        for (Wheel wheel : wheels)
        {
            Symbol newSymbol = new Symbol(color);

            int position = pos;

            if (position < 1)
            {
                position = 1;
            }

            if (position > wheel.size() + 1)
            {
                position = wheel.size() + 1;
            }

            wheel.addSymbol(position - 1, newSymbol);
        }

        lastOperation = true;
    }

    /**
     * Elimina de todas las ruedas el símbolo identificado
     * por el color indicado.
     *
     * @param symbol color del símbolo que se eliminará
     */
    public void delSymbol(String symbol)
    {
        boolean removed = false;

        for (Wheel wheel : wheels)
        {
            if (wheel.delSymbol(symbol))
            {
                removed = true;
            }
        }

        if (!removed)
        {
            showError("No se encontró el símbolo.");
        }

        lastOperation = removed;
    }

    /**
     * Coloca un símbolo como visible en la rueda indicada.
     *
     * @param wheel posición de la rueda
     * @param symbol posición del símbolo
     */
    public void placeSymbol(int wheel, int symbol)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        if (wheel < 1)
        {
            wheel = 1;
        }

        if (wheel > wheels.size())
        {
            wheel = wheels.size();
        }

        Wheel selectedWheel = wheels.get(wheel - 1);

        if (selectedWheel.size() == 0)
        {
            showError("La rueda no tiene símbolos.");
            lastOperation = false;
            return;
        }

        if (symbol < 1)
        {
            symbol = 1;
        }

        if (symbol > selectedWheel.size())
        {
            symbol = selectedWheel.size();
        }

        if (visible)
        {
            selectedWheel.makeInvisible();
        }

        lastOperation = selectedWheel.placeSymbol(symbol - 1);

        if (visible)
        {
            selectedWheel.makeVisible();
        }
    }

    /**
     * Gira todas las ruedas de la máquina.
     */
    public void spin()
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas para girar.");
            lastOperation = false;
            return;
        }

        boolean hasSymbols = false;

        for (Wheel wheel : wheels)
        {
            if (wheel.size() > 0)
            {
                if (visible)
                {
                    wheel.makeInvisible();
                }

                wheel.spin();

                if (visible)
                {
                    wheel.makeVisible();
                }

                hasSymbols = true;
            }
        }

        if (!hasSymbols)
        {
            showError("No hay símbolos para girar.");
        }

        lastOperation = hasSymbols;
    }

    /**
     * Retorna los símbolos visibles de todas las ruedas,
     * de izquierda a derecha.
     *
     * @return arreglo con los colores visibles
     */
    public String[] configuration()
    {
        String[] result = new String[wheels.size()];

        for (int i = 0; i < wheels.size(); i++)
        {
            Symbol current = wheels.get(i).getCurrentSymbol();

            if (current != null)
            {
                result[i] = current.getColor();
            }
            else
            {
                result[i] = null;
            }
        }

        lastOperation = true;
        return result;
    }

    /**
     * Retorna los símbolos de la máquina en el orden
     * en que aparecen en las ruedas.
     *
     * @return arreglo con los colores de los símbolos
     */
    public String[] symbols()
    {
        ArrayList<String> result = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            for (int i = 0; i < wheel.size(); i++)
            {
                Symbol symbol = wheel.getSymbol(i);
                result.add(symbol.getColor());
            }
        }

        lastOperation = true;
        return result.toArray(new String[result.size()]);
    }

    /**
     * Retorna la cantidad de símbolos diferentes
     * que existen en la máquina.
     *
     * @return cantidad de símbolos diferentes
     */
    public int distinctSymbols()
    {
        ArrayList<String> different = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            for (int i = 0; i < wheel.size(); i++)
            {
                String color = wheel.getSymbol(i).getColor();

                if (!different.contains(color))
                {
                    different.add(color);
                }
            }
        }

        lastOperation = true;
        return different.size();
    }

    /**
     * Determina si la configuración actual es ganadora.
     * Hay jackpot cuando todas las ruedas muestran
     * el mismo símbolo.
     *
     * @return true si la configuración es ganadora
     */
    public boolean isJackpot()
    {
        if (wheels.isEmpty())
        {
            jackpot = false;
            machineBody.changeColor("red");
            lastOperation = false;
            return false;
        }
    
        String[] currentConfiguration = configuration();
    
        if (currentConfiguration.length == 0)
        {
            jackpot = false;
            machineBody.changeColor("red");
            lastOperation = false;
            return false;
        }
    
        String firstSymbol = currentConfiguration[0];
    
        if (firstSymbol == null)
        {
            jackpot = false;
            machineBody.changeColor("red");
            lastOperation = false;
            return false;
        }
    
        for (int i = 1; i < currentConfiguration.length; i++)
        {
            if (currentConfiguration[i] == null ||
                !currentConfiguration[i].equals(firstSymbol))
            {
                jackpot = false;
                machineBody.changeColor("red");
                lastOperation = true;
                return false;
            }
        }
    
        jackpot = true;
        machineBody.changeColor("green");
        lastOperation = true;
        return true;
    }

    public void makeVisible()
    {
        visible = true;
    
        machineBody.makeVisible();
    
        for (Wheel wheel : wheels)
        {
            wheel.makeVisible();
        }
    
        lastOperation = true;
    }

    public void makeInvisible()
    {
        machineBody.makeInvisible();
    
        for (Wheel wheel : wheels)
        {
            wheel.makeInvisible();
        }
    
        visible = false;
        lastOperation = true;
    }

    /**
     * Termina el simulador y oculta sus elementos.
     */
    public void exit()
    {
        makeInvisible();
        lastOperation = true;
    }
    
    /**
     * Organiza visualmente las ruedas de izquierda a derecha.
     */
    private void organizeWheels()
    {
        for (int i = 0; i < wheels.size(); i++)
        {
            wheels.get(i).setHorizontalPosition(i * 100);
        }
    }
    
    /**
     * Muestra un mensaje de error únicamente cuando
     * el simulador está visible.
     *
     * @param message mensaje que se mostrará
     */
    private void showError(String message)
    {
        if (visible)
        {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                message
            );
        }
    }
}