import java.util.ArrayList;

/**
 * Representa una rueda de la máquina tragamonedas.
 * Una rueda contiene varios símbolos y muestra uno de ellos.
 *
 * @version 1.0
 */
public class Wheel
{
    private ArrayList<Symbol> symbols;
    private int currentSymbol;
    private int horizontalPosition;
    private boolean locked;

    /**
     * Construye una rueda vacía.
     */
    public Wheel()
    {
        symbols = new ArrayList<Symbol>();
        currentSymbol = 0;
        horizontalPosition = 0;
        locked = false;
    }

    /**
     * Agrega un símbolo a la rueda.
     *
     * @param symbol símbolo que se agregará
     */
    public void addSymbol(Symbol symbol)
    {
        symbol.moveHorizontal(horizontalPosition);
        symbols.add(symbol);
    }

    /**
     * Elimina el símbolo que se encuentra en la posición indicada.
     *
     * @param position posición del símbolo
     * @return true si se pudo eliminar
     */
    public boolean delSymbol(int position)
    {
        if (position >= 0 && position < symbols.size())
        {
            symbols.remove(position);

            if (currentSymbol >= symbols.size())
            {
                currentSymbol = 0;
            }

            return true;
        }

        return false;
    }

    /**
     * Gira la rueda un paso hacia el siguiente símbolo.
     */
    public void spin()
    {
        spin(1);
    }

    /**
     * Gira la rueda la cantidad de pasos indicada.
     * Los pasos positivos avanzan y los negativos retroceden.
     *
     * @param steps cantidad de pasos
     */
    public void spin(int steps)
    {
        if (symbols.isEmpty() || locked)
        {
            return;
        }

        int size = symbols.size();
        int newPosition = (currentSymbol + steps) % size;

        if (newPosition < 0)
        {
            newPosition += size;
        }

        currentSymbol = newPosition;
    }

    /**
     * Retorna el símbolo que está actualmente visible.
     *
     * @return símbolo visible o null si no existen símbolos
     */
    public Symbol getCurrentSymbol()
    {
        if (symbols.isEmpty())
        {
            return null;
        }

        return symbols.get(currentSymbol);
    }

    /**
     * Agrega un símbolo en una posición determinada.
     *
     * @param position posición interna donde se agregará
     * @param symbol símbolo que se agregará
     */
    public void addSymbol(int position, Symbol symbol)
    {
        if (position < 0)
        {
            position = 0;
        }

        if (position > symbols.size())
        {
            position = symbols.size();
        }

        symbol.moveHorizontal(horizontalPosition);
        symbols.add(position, symbol);
    }

    /**
     * Busca y elimina un símbolo usando su color.
     *
     * @param color color del símbolo que se eliminará
     * @return true si el símbolo fue encontrado y eliminado
     */
    public boolean delSymbol(String color)
    {
        for (int i = 0; i < symbols.size(); i++)
        {
            if (symbols.get(i).getColor().equals(color))
            {
                symbols.remove(i);

                if (symbols.isEmpty())
                {
                    currentSymbol = 0;
                }
                else if (currentSymbol >= symbols.size())
                {
                    currentSymbol = 0;
                }

                return true;
            }
        }

        return false;
    }

    /**
     * Retorna el símbolo ubicado en una posición interna.
     *
     * @param position posición del símbolo
     * @return el símbolo solicitado o null si no existe
     */
    public Symbol getSymbol(int position)
    {
        if (position >= 0 && position < symbols.size())
        {
            return symbols.get(position);
        }

        return null;
    }

    /**
     * Retorna la cantidad de símbolos de la rueda.
     *
     * @return cantidad de símbolos
     */
    public int size()
    {
        return symbols.size();
    }

    /**
     * Selecciona el símbolo que quedará visible.
     *
     * @param position posición interna del símbolo
     * @return true si la operación se realizó correctamente
     */
    public boolean placeSymbol(int position)
    {
        if (position >= 0 && position < symbols.size())
        {
            currentSymbol = position;
            return true;
        }

        return false;
    }

    /**
     * Hace visible el símbolo actual de la rueda.
     */
    public void makeVisible()
    {
        Symbol current = getCurrentSymbol();

        if (current != null)
        {
            current.makeVisible();
        }
    }

    /**
     * Hace invisible todos los símbolos de la rueda.
     */
    public void makeInvisible()
    {
        for (Symbol symbol : symbols)
        {
            symbol.makeInvisible();
        }
    }

    /**
     * Establece la posición horizontal de la rueda.
     *
     * @param position nueva posición horizontal
     */
    public void setHorizontalPosition(int position)
    {
        int distance = position - horizontalPosition;

        for (Symbol symbol : symbols)
        {
            symbol.moveHorizontal(distance);
        }

        horizontalPosition = position;
    }
    
    /**
     * Bloquea la rueda para impedir que sea modificada mediante las
     * operaciones que dependen de su estado de bloqueo.
     */
    public void lock()
    {
        locked = true;
    }
    
    /**
     * Desbloquea la rueda para permitir nuevamente sus operaciones.
     */
    public void unlock()
    {
        locked = false;
    }
    
    /**
     * Consulta si la rueda se encuentra bloqueada.
     * 
     * @return true si la rueda está bloqueada, false en caso contrario
     */
    public boolean isLocked()
    {
        return locked;
    }
        
}