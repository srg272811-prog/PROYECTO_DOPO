import junit.framework.*;

/**
 * Pruebas unitarias de SlotMachineContest.
 *
 * @version 1.0
 */
public class SlotMachineContestTest extends TestCase
{
    public void testSolveThreeWheels()
    {
        SlotMachineContest contest = new SlotMachineContest();

        int[][] actions = contest.solve(3);

        assertTrue(actions.length > 0);
        assertTrue(actions.length <= 10000);
        assertTrue(contest.lastSolutionWasJackpot());
    }

    public void testSolveFiveWheels()
    {
        SlotMachineContest contest = new SlotMachineContest();

        int[][] actions = contest.solve(5);

        assertTrue(actions.length > 0);
        assertTrue(actions.length <= 10000);
        assertTrue(contest.lastSolutionWasJackpot());
    }

    public void testActionsHaveTwoValues()
    {
        SlotMachineContest contest = new SlotMachineContest();

        int[][] actions = contest.solve(4);

        for (int[] action : actions)
        {
            assertEquals(2, action.length);
            assertTrue(action[0] >= 1 && action[0] <= 4);
            assertTrue(action[1] != 0);
        }
    }

    public void testInvalidN()
    {
        SlotMachineContest contest = new SlotMachineContest();

        try
        {
            contest.solve(2);
            fail("Se esperaba una excepción.");
        }
        catch (IllegalArgumentException expected)
        {
            assertTrue(true);
        }
    }
}
