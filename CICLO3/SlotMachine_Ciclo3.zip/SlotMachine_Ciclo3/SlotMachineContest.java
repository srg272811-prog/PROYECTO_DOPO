import java.util.ArrayList;

/**
 * Resuelve y simula el problema de la maratón ICPC 2025:
 * Slot Machine.
 *
 * La clase usa SlotMachine como testing tool en solve y como
 * simulador visual en simulate.
 *
 * @version 1.0
 */
public class SlotMachineContest
{
    private SlotMachine lastMachine;
    private int[][] lastSolution;

    /**
     * Resuelve el problema usando una máquina invisible.
     *
     * @param n número de ruedas y símbolos
     * @return secuencia de acciones {rueda, pasos}
     */
    public int[][] solve(int n)
    {
        validateN(n);

        lastMachine = new SlotMachine(n);
        lastSolution = solveMachine(lastMachine, n);

        return copyActions(lastSolution);
    }

    /**
     * Simula visualmente la solución del problema.
     *
     * @param n número de ruedas y símbolos
     */
    public void simulate(int n)
    {
        validateN(n);

        lastMachine = new SlotMachine(n);
        lastMachine.makeVisible();

        Canvas.getCanvas().wait(500);

        lastSolution = solveMachine(lastMachine, n);

        Canvas.getCanvas().wait(800);
    }

    /**
     * Permite comprobar desde las pruebas que la última solución
     * dejó la máquina en jackpot.
     *
     * @return true si la última máquina tiene un solo símbolo visible
     */
    public boolean lastSolutionWasJackpot()
    {
        return lastMachine != null && lastMachine.distinctSymbols() == 1;
    }

    /**
     * Ejecuta el algoritmo sobre una máquina.
     *
     * Primera fase:
     * deja las ruedas mostrando símbolos diferentes.
     *
     * Segunda fase:
     * encuentra, para cada rueda, cuál es la siguiente rueda
     * en el orden cíclico de los símbolos.
     *
     * Tercera fase:
     * gira cada rueda hasta que todas muestren el mismo símbolo.
     */
    private int[][] solveMachine(SlotMachine machine, int n)
    {
        ArrayList<int[]> actions = new ArrayList<int[]>();

        // Mini-ciclo 1: construir una configuración con n símbolos distintos.
        for (int wheel = 1; wheel <= n; wheel++)
        {
            int bestPosition = 0;
            int bestDistinct = machine.distinctSymbols();

            // Recorremos las demás posiciones de la rueda.
            for (int step = 1; step < n; step++)
            {
                rotate(machine, actions, wheel, 1);

                int currentDistinct = machine.distinctSymbols();

                if (currentDistinct > bestDistinct)
                {
                    bestDistinct = currentDistinct;
                    bestPosition = step;
                }
            }

            // Después de n-1 pasos estamos en la posición inicial - 1.
            int adjustment = bestPosition - (n - 1);
            adjustment %= n;

            if (adjustment < 0)
            {
                adjustment += n;
            }

            if (adjustment != 0)
            {
                rotate(machine, actions, wheel, adjustment);
            }
        }

        // Mini-ciclo 2: encontrar el sucesor de cada rueda.
        int[] next = new int[n + 1];

        for (int wheel = 1; wheel <= n; wheel++)
        {
            for (int candidate = 1; candidate <= n; candidate++)
            {
                if (candidate == wheel)
                {
                    continue;
                }

                // Si candidate es la siguiente rueda, mover
                // wheel +1 y candidate -1 conserva los n símbolos.
                rotate(machine, actions, wheel, 1);
                rotate(machine, actions, candidate, -1);

                boolean isNext = machine.distinctSymbols() == n;

                // Restaurar exactamente la configuración anterior.
                rotate(machine, actions, candidate, 1);
                rotate(machine, actions, wheel, -1);

                if (isNext)
                {
                    next[wheel] = candidate;
                    break;
                }
            }
        }

        // Mini-ciclo 3: recorrer el ciclo y alinear todas las ruedas.
        int[] order = new int[n];
        order[0] = 1;

        for (int i = 1; i < n; i++)
        {
            order[i] = next[order[i - 1]];
        }

        for (int i = 1; i < n; i++)
        {
            rotate(machine, actions, order[i], -i);
        }

        return actions.toArray(new int[actions.size()][]);
    }

    /**
     * Registra y ejecuta una acción.
     */
    private void rotate(
        SlotMachine machine,
        ArrayList<int[]> actions,
        int wheel,
        int steps)
    {
        if (steps == 0)
        {
            return;
        }

        machine.spin(wheel, steps);
        actions.add(new int[] {wheel, steps});
    }

    private int[][] copyActions(int[][] actions)
    {
        int[][] copy = new int[actions.length][];

        for (int i = 0; i < actions.length; i++)
        {
            copy[i] = new int[] {actions[i][0], actions[i][1]};
        }

        return copy;
    }

    private void validateN(int n)
    {
        if (n < SlotMachine.MIN_WHEELS ||
            n > SlotMachine.MAX_WHEELS)
        {
            throw new IllegalArgumentException(
                "n debe estar entre 3 y 50."
            );
        }
    }
}
