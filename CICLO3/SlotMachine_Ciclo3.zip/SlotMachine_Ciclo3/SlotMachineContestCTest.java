import junit.framework.*;

/**
 * Pruebas compartidas de SlotMachineContest.
 *
 * @version 1.0
 */
public class SlotMachineContestCTest extends TestCase
{
    public void testSharedSolve()
    {
        SlotMachineContest contest = new SlotMachineContest();

        int[][] actions = contest.solve(3);

        assertTrue(actions.length <= 10000);
        assertTrue(contest.lastSolutionWasJackpot());
    }

    public void testSharedSolveWithSevenWheels()
    {
        SlotMachineContest contest = new SlotMachineContest();

        int[][] actions = contest.solve(7);

        assertTrue(actions.length <= 10000);
        assertTrue(contest.lastSolutionWasJackpot());
    }
}
