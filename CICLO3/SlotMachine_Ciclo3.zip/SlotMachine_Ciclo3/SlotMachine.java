import java.util.ArrayList;
import java.util.Random;

/**
 * Simula una máquina tragamonedas formada por varias ruedas.
 *
 * En el Ciclo 3 se agrega el constructor SlotMachine(n), que crea
 * exactamente n ruedas y n símbolos por rueda.
 *
 * @version 2.0
 */
public class SlotMachine
{
    public static final int MIN_WHEELS = 3;
    public static final int MAX_WHEELS = 50;

    private ArrayList<Wheel> wheels;
    private boolean visible;
    private boolean lastOperation;
    private Rectangle machineBody;
    private Rectangle topPanel;
    private Rectangle bottomPanel;
    private Rectangle lever;
    private Circle leverKnob;
    private ArrayList<Rectangle> windowFrames;
    private ArrayList<Rectangle> windows;
    private boolean jackpot;

    /**
     * Construye una máquina con el mínimo permitido de ruedas.
     */
    public SlotMachine()
    {
        this(MIN_WHEELS);
    }

    /**
     * Construye una máquina con n ruedas y n símbolos distintos.
     *
     * @param n número de ruedas y de símbolos
     * @throws IllegalArgumentException si n no está entre 3 y 50
     */
    public SlotMachine(int n)
    {
        if (n < MIN_WHEELS || n > MAX_WHEELS)
        {
            throw new IllegalArgumentException(
                "El número de ruedas debe estar entre 3 y 50."
            );
        }

        wheels = new ArrayList<Wheel>();
        windowFrames = new ArrayList<Rectangle>();
        windows = new ArrayList<Rectangle>();
        visible = false;
        lastOperation = true;
        jackpot = false;

        createMachineBody(n);

        for (int i = 1; i <= n; i++)
        {
            addWheel(i);
        }

        String[] colors = createColors(n);
        for (int i = 1; i < n; i++)
        {
            addSymbol(i + 1, colors[i]);
        }

        randomizeConfiguration(n);
    }

    /**
     * Crea la parte visual principal de la máquina.
     */
    private void createMachineBody(int n)
    {
        int width = Math.max(310, n * 90 + 40);

        machineBody = new Rectangle();
        machineBody.changeSize(220, width);
        machineBody.changeColor("red");
        machineBody.moveHorizontal(-50);
        machineBody.moveVertical(65);

        topPanel = new Rectangle();
        topPanel.changeSize(40, width - 20);
        topPanel.changeColor("black");
        topPanel.moveHorizontal(-40);
        topPanel.moveVertical(75);

        bottomPanel = new Rectangle();
        bottomPanel.changeSize(35, width - 20);
        bottomPanel.changeColor("black");
        bottomPanel.moveHorizontal(-40);
        bottomPanel.moveVertical(255);

        /*
         * Se conservan los objetos de la palanca para no cambiar
         * la estructura de la clase, pero se colocan fuera de la
         * zona visible de la máquina.
         */
        lever = new Rectangle();
        lever.changeSize(1, 1);
        lever.changeColor("black");
        lever.moveHorizontal(-1000);
        lever.moveVertical(-1000);

        leverKnob = new Circle();
        leverKnob.changeSize(1);
        leverKnob.changeColor("black");
        leverKnob.moveHorizontal(-1000);
        leverKnob.moveVertical(-1000);
    }

    /**
     * Crea los marcos y fondos de las ventanas visuales.
     */
    private void createWindow(int position)
    {
        int xDistance = -25 + (position - 1) * 90;

        Rectangle frame = new Rectangle();
        frame.changeSize(84, 72);
        frame.changeColor("orange");
        frame.moveHorizontal(xDistance + 3);
        frame.moveVertical(132);

        Rectangle window = new Rectangle();
        window.changeSize(76, 64);
        window.changeColor("black");
        window.moveHorizontal(xDistance + 7);
        window.moveVertical(136);

        windowFrames.add(frame);
        windows.add(window);
    }

    /**
     * Genera n colores distintos. Se usan colores con nombre para los
     * primeros símbolos y colores hexadecimales para permitir n hasta 50.
     */
    private String[] createColors(int n)
    {
        String[] colors = new String[n];

        String[] baseColors = {
            "red", "blue", "green", "yellow",
            "magenta", "cyan", "orange", "pink"
        };

        for (int i = 0; i < n; i++)
        {
            if (i < baseColors.length)
            {
                colors[i] = baseColors[i];
            }
            else
            {
                int red = (i * 73 + 50) % 256;
                int green = (i * 151 + 80) % 256;
                int blue = (i * 197 + 110) % 256;

                colors[i] = String.format(
                    "#%02X%02X%02X", red, green, blue
                );
            }
        }

        return colors;
    }

    /**
     * Aleatoriza la configuración inicial.
     */
    private void randomizeConfiguration(int n)
    {
        Random random = new Random();

        for (int i = 1; i <= n; i++)
        {
            int steps = random.nextInt(n);
            if (steps > 0)
            {
                spin(i, steps);
            }
        }

        lastOperation = true;
    }

    /**
     * Intercambia dos ruedas de la máquina.
     *
     * @param wheel1 posición de la primera rueda
     * @param wheel2 posición de la segunda rueda
     */
    public void swap(int wheel1, int wheel2)
    {
        if (wheel1 < 1 || wheel1 > wheels.size() ||
            wheel2 < 1 || wheel2 > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }

        Wheel first = wheels.get(wheel1 - 1);
        Wheel second = wheels.get(wheel2 - 1);

        wheels.set(wheel1 - 1, second);
        wheels.set(wheel2 - 1, first);

        organizeWheels();
        lastOperation = true;
    }

    /**
     * Bloquea una rueda.
     *
     * @param wheel posición de la rueda
     */
    public void lock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else
        {
            wheels.get(wheel - 1).lock();
            lastOperation = true;
        }
    }

    /**
     * Desbloquea una rueda.
     *
     * @param wheel posición de la rueda
     */
    public void unlock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else
        {
            wheels.get(wheel - 1).unlock();
            lastOperation = true;
        }
    }

    /**
     * Gira una rueda la cantidad de pasos indicada.
     * Los pasos negativos permiten girar en sentido contrario.
     *
     * @param wheel posición de la rueda
     * @param steps número de pasos
     */
    public void spin(int wheel, int steps)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }

        Wheel selectedWheel = wheels.get(wheel - 1);

        if (selectedWheel.isLocked())
        {
            lastOperation = false;
            showError("Wheel is locked");
            return;
        }

        int direction = steps < 0 ? -1 : 1;
        int repetitions = Math.abs(steps);

        for (int i = 0; i < repetitions; i++)
        {
            if (visible)
            {
                selectedWheel.makeInvisible();
            }

            selectedWheel.spin(direction);

            if (visible)
            {
                selectedWheel.makeVisible();
                Canvas.getCanvas().wait(70);
            }
        }

        lastOperation = true;
    }

    /**
     * Deja la máquina en la configuración indicada.
     *
     * @param setSymbols colores deseados, uno por rueda
     */
    public void spin(String[] setSymbols)
    {
        if (setSymbols == null || setSymbols.length != wheels.size())
        {
            lastOperation = false;
            showError("Invalid configuration");
            return;
        }

        for (int i = 0; i < wheels.size(); i++)
        {
            Wheel currentWheel = wheels.get(i);
            int position = -1;

            for (int j = 0; j < currentWheel.size(); j++)
            {
                Symbol symbol = currentWheel.getSymbol(j);

                if (symbol.getColor().equals(setSymbols[i]))
                {
                    position = j;
                    break;
                }
            }

            if (position == -1 || currentWheel.isLocked())
            {
                lastOperation = false;
                showError("Invalid configuration");
                return;
            }
        }

        for (int i = 0; i < wheels.size(); i++)
        {
            Wheel currentWheel = wheels.get(i);
            int position = -1;

            for (int j = 0; j < currentWheel.size(); j++)
            {
                if (currentWheel.getSymbol(j).getColor().equals(setSymbols[i]))
                {
                    position = j;
                    break;
                }
            }

            currentWheel.placeSymbol(position);
        }

        lastOperation = true;
    }

    /**
     * Agrega una rueda respetando el mínimo de tres ruedas.
     *
     * @param pos posición donde se agregará
     */
    public void addWheel(int pos)
    {
        if (wheels.size() >= MAX_WHEELS)
        {
            lastOperation = false;
            showError("Maximum number of wheels reached.");
            return;
        }
    
        Wheel newWheel = new Wheel();
        newWheel.addSymbol(new Symbol("red"));
    
        if (pos < 1)
        {
            pos = 1;
        }
    
        if (pos > wheels.size() + 1)
        {
            pos = wheels.size() + 1;
        }
    
        int insertionIndex = pos - 1;
    
        // Desplazar las ventanas que ya estaban a la derecha.
        for (int i = windowFrames.size() - 1;
             i >= insertionIndex; i--)
        {
            windowFrames.get(i).moveHorizontal(90);
            windows.get(i).moveHorizontal(90);
        }
    
        wheels.add(insertionIndex, newWheel);
    
        createWindow(pos);
    
        organizeWheels();
    
        // Ajustar el tamaño de la máquina.
        resizeMachine();
        organizeVisualOrder();
    
        lastOperation = true;
    }

    /**
     * Elimina una rueda sin permitir que la máquina tenga menos de tres.
     *
     * @param pos posición de la rueda
     */
    public void delWheel(int pos)
    {
        if (wheels.size() <= MIN_WHEELS)
        {
            showError("La máquina debe tener mínimo 3 ruedas.");
            lastOperation = false;
            return;
        }
    
        if (pos < 1 || pos > wheels.size())
        {
            showError("Invalid wheel position");
            lastOperation = false;
            return;
        }
    
        /*
         * Primero obtenemos la rueda que vamos a eliminar
         * y la hacemos invisible.
         */
        Wheel removedWheel = wheels.get(pos - 1);
    
        if (visible)
        {
            removedWheel.makeInvisible();
        }
    
        wheels.remove(pos - 1);
    
        int removedIndex = pos - 1;
    
        Rectangle frame = windowFrames.remove(removedIndex);
        Rectangle window = windows.remove(removedIndex);
    
        frame.makeInvisible();
        window.makeInvisible();
    
        /*
         * Mover las ventanas que estaban después
         * de la rueda eliminada.
         */
        for (int i = removedIndex;
             i < windowFrames.size(); i++)
        {
            windowFrames.get(i).moveHorizontal(-90);
            windows.get(i).moveHorizontal(-90);
        }
    
        organizeWheels();
    
        // Reducir nuevamente el tamaño de la máquina.
        resizeMachine();
        organizeVisualOrder();
    
        lastOperation = true;
    }

    /**
     * Indica si la última operación fue exitosa.
     *
     * @return true si fue exitosa
     */
    public boolean ok()
    {
        return lastOperation;
    }

    /**
     * Agrega un símbolo del color indicado a todas las ruedas.
     *
     * @param pos posición del símbolo
     * @param color color del símbolo
     */
    public void addSymbol(int pos, String color)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        for (Wheel wheel : wheels)
        {
            Symbol newSymbol = new Symbol(color);

            int position = pos;

            if (position < 1)
            {
                position = 1;
            }

            if (position > wheel.size() + 1)
            {
                position = wheel.size() + 1;
            }

            wheel.addSymbol(position - 1, newSymbol);
        }

        lastOperation = true;
    }

    /**
     * Elimina de todas las ruedas el símbolo indicado.
     *
     * @param symbol color del símbolo
     */
    public void delSymbol(String symbol)
    {
        boolean removed = false;

        for (Wheel wheel : wheels)
        {
            if (wheel.delSymbol(symbol))
            {
                removed = true;
            }
        }

        if (!removed)
        {
            showError("No se encontró el símbolo.");
        }

        lastOperation = removed;
    }

    /**
     * Coloca un símbolo como visible en una rueda.
     *
     * @param wheel posición de la rueda
     * @param symbol posición del símbolo
     */
    public void placeSymbol(int wheel, int symbol)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }

        Wheel selectedWheel = wheels.get(wheel - 1);

        if (selectedWheel.size() == 0)
        {
            showError("La rueda no tiene símbolos.");
            lastOperation = false;
            return;
        }

        if (symbol < 1 || symbol > selectedWheel.size())
        {
            lastOperation = false;
            showError("Invalid symbol position");
            return;
        }

        if (visible)
        {
            selectedWheel.makeInvisible();
        }

        lastOperation = selectedWheel.placeSymbol(symbol - 1);

        if (visible)
        {
            selectedWheel.makeVisible();
        }
    }

    /**
     * Gira todas las ruedas un paso.
     */
    public void spin()
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas para girar.");
            lastOperation = false;
            return;
        }
    
        for (Wheel wheel : wheels)
        {
            if (!wheel.isLocked())
            {
                if (visible)
                {
                    wheel.makeInvisible();
                }
    
                wheel.spin();
    
                if (visible)
                {
                    wheel.makeVisible();
                }
            }
        }
    
        lastOperation = true;
    }

    /**
     * Retorna la configuración actual.
     *
     * @return colores visibles de izquierda a derecha
     */
    public String[] configuration()
    {
        String[] result = new String[wheels.size()];

        for (int i = 0; i < wheels.size(); i++)
        {
            Symbol current = wheels.get(i).getCurrentSymbol();
            result[i] = current == null ? null : current.getColor();
        }

        lastOperation = true;
        return result;
    }

    /**
     * Retorna todos los símbolos de la máquina.
     *
     * @return arreglo de colores
     */
    public String[] symbols()
    {
        ArrayList<String> result = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            for (int i = 0; i < wheel.size(); i++)
            {
                result.add(wheel.getSymbol(i).getColor());
            }
        }

        lastOperation = true;
        return result.toArray(new String[result.size()]);
    }

    /**
     * Cuenta los símbolos diferentes visibles.
     *
     * @return número de símbolos diferentes
     */
    public int distinctSymbols()
    {
        ArrayList<String> different = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            Symbol symbol = wheel.getCurrentSymbol();

            if (symbol != null && !different.contains(symbol.getColor()))
            {
                different.add(symbol.getColor());
            }
        }

        lastOperation = true;
        return different.size();
    }

    /**
     * Determina si existe jackpot.
     *
     * @return true si todas las ruedas muestran el mismo símbolo
     */
    public boolean isJackpot()
    {
        if (wheels.size() < MIN_WHEELS)
        {
            jackpot = false;
            machineBody.changeColor("red");
            organizeVisualOrder();
            lastOperation = false;
            return false;
        }
    
        String[] currentConfiguration = configuration();
    
        String firstSymbol = currentConfiguration[0];
    
        if (firstSymbol == null)
        {
            jackpot = false;
            machineBody.changeColor("red");
            organizeVisualOrder();
            lastOperation = false;
            return false;
        }
    
        for (int i = 1; i < currentConfiguration.length; i++)
        {
            if (currentConfiguration[i] == null ||
                !currentConfiguration[i].equals(firstSymbol))
            {
                jackpot = false;
                machineBody.changeColor("red");
                organizeVisualOrder();
                lastOperation = true;
                return false;
            }
        }
    
        jackpot = true;
        machineBody.changeColor("green");
    
        /*
         * Volvemos a poner las ventanas y ruedas
         * por encima del cuerpo de la máquina.
         */
        organizeVisualOrder();
    
        lastOperation = true;
        return true;
    }

    /**
     * Hace visible la máquina completa.
     */
    public void makeVisible()
    {
        visible = true;

        machineBody.makeVisible();
        topPanel.makeVisible();
        bottomPanel.makeVisible();
        lever.makeVisible();
        leverKnob.makeVisible();

        for (Rectangle frame : windowFrames)
        {
            frame.makeVisible();
        }

        for (Rectangle window : windows)
        {
            window.makeVisible();
        }

        for (Wheel wheel : wheels)
        {
            wheel.makeVisible();
        }

        lastOperation = true;
    }

    /**
     * Oculta la máquina completa.
     */
    public void makeInvisible()
    {
        machineBody.makeInvisible();
        topPanel.makeInvisible();
        bottomPanel.makeInvisible();
        lever.makeInvisible();
        leverKnob.makeInvisible();

        for (Rectangle frame : windowFrames)
        {
            frame.makeInvisible();
        }

        for (Rectangle window : windows)
        {
            window.makeInvisible();
        }

        for (Wheel wheel : wheels)
        {
            wheel.makeInvisible();
        }

        visible = false;
        lastOperation = true;
    }

    /**
     * Termina el simulador.
     */
    public void exit()
    {
        makeInvisible();
        lastOperation = true;
    }

    /**
     * Organiza nuevamente las piezas visuales para que
     * el cuerpo de la máquina quede detrás de las ventanas
     * y de las ruedas.
     */
    private void organizeVisualOrder()
    {
        if (!visible)
        {
            return;
        }
    
        machineBody.makeInvisible();
        topPanel.makeInvisible();
        bottomPanel.makeInvisible();
    
        for (Rectangle frame : windowFrames)
        {
            frame.makeInvisible();
        }
    
        for (Rectangle window : windows)
        {
            window.makeInvisible();
        }
    
        for (Wheel wheel : wheels)
        {
            wheel.makeInvisible();
        }
    
        machineBody.makeVisible();
        topPanel.makeVisible();
        bottomPanel.makeVisible();
    
        for (Rectangle frame : windowFrames)
        {
            frame.makeVisible();
        }
    
        for (Rectangle window : windows)
        {
            window.makeVisible();
        }
    
        for (Wheel wheel : wheels)
        {
            wheel.makeVisible();
        }
    }
    
    /**
     * Organiza las ruedas de izquierda a derecha.
     */
    private void organizeWheels()
    {
        for (int i = 0; i < wheels.size(); i++)
        {
            wheels.get(i).setHorizontalPosition(i * 90);
        }
    }
    
    /**
     * Ajusta el tamaño visual de la máquina al número actual de ruedas.
     */
    private void resizeMachine()
    {
        int width = Math.max(310, wheels.size() * 90 + 40);
    
        machineBody.changeSize(220, width);
        topPanel.changeSize(40, width - 20);
        bottomPanel.changeSize(35, width - 20);
    }
    
    private void showError(String message)
    {
        if (visible)
        {
            javax.swing.JOptionPane.showMessageDialog(null, message);
        }
    }
}