import junit.framework.*;

/**
 * Pruebas unitarias compartidas del proyecto SlotMachine.
 *
 * @version 2.0
 */
public class SlotMachineCC2Test extends TestCase
{
    public void testMinimumWheelsShared()
    {
        SlotMachine machine = new SlotMachine();

        machine.delWheel(1);

        assertFalse(machine.ok());
        assertEquals(3, machine.configuration().length);
    }

    public void testDistinctSymbolsShared()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.placeSymbol(1, 1);
        machine.placeSymbol(2, 1);
        machine.placeSymbol(3, 2);

        assertEquals(2, machine.distinctSymbols());
    }
}
