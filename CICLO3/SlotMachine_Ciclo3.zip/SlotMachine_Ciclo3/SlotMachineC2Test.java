import junit.framework.*;

/**
 * Pruebas unitarias del proyecto SlotMachine.
 *
 * @version 2.0
 */
public class SlotMachineC2Test extends TestCase
{
    public void testMinimumWheels()
    {
        SlotMachine machine = new SlotMachine();

        assertEquals(3, machine.configuration().length);

        machine.delWheel(1);

        assertFalse(machine.ok());
        assertEquals(3, machine.configuration().length);
    }

    public void testSwap()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 2);
        machine.placeSymbol(2, 3);

        String beforeFirst = machine.configuration()[0];
        String beforeSecond = machine.configuration()[1];

        machine.swap(1, 2);

        String[] after = machine.configuration();

        assertEquals(beforeFirst, after[1]);
        assertEquals(beforeSecond, after[0]);
    }

    public void testLockUnlock()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 2);
        String before = machine.configuration()[0];

        machine.lock(1);
        machine.spin(1, 1);

        assertEquals(before, machine.configuration()[0]);
        assertFalse(machine.ok());

        machine.unlock(1);
        machine.spin(1, 1);

        assertTrue(machine.ok());
        assertFalse(before.equals(machine.configuration()[0]));
    }

    public void testSpinStepsPositive()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 1);
        String first = machine.configuration()[0];

        machine.spin(1, 2);

        assertEquals(first, machine.configuration()[0]);
    }

    public void testSpinStepsNegative()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 2);
        String expected = machine.configuration()[0];

        machine.spin(1, -2);

        assertEquals(expected, machine.configuration()[0]);
    }

    public void testSpinConfiguration()
    {
        SlotMachine machine = new SlotMachine();

        String[] configuration = machine.symbols();
        String[] target = {
            configuration[0],
            configuration[3],
            configuration[6]
        };

        machine.spin(target);

        assertEquals(target[0], machine.configuration()[0]);
        assertEquals(target[1], machine.configuration()[1]);
        assertEquals(target[2], machine.configuration()[2]);
    }

    public void testDistinctSymbols()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 1);
        machine.placeSymbol(2, 1);
        machine.placeSymbol(3, 1);

        assertEquals(1, machine.distinctSymbols());

        machine.placeSymbol(2, 2);

        assertEquals(2, machine.distinctSymbols());
    }

    public void testInvalidWheel()
    {
        SlotMachine machine = new SlotMachine();

        machine.spin(99, 1);

        assertFalse(machine.ok());
    }

    public void testInvalidNegativeConfiguration()
    {
        SlotMachine machine = new SlotMachine();

        machine.spin(99, -1);

        assertFalse(machine.ok());
    }

    public void testJackpot()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 1);
        machine.placeSymbol(2, 1);
        machine.placeSymbol(3, 1);

        assertTrue(machine.isJackpot());
    }

    public void testNotJackpot()
    {
        SlotMachine machine = new SlotMachine();

        machine.placeSymbol(1, 1);
        machine.placeSymbol(2, 2);

        assertFalse(machine.isJackpot());
    }

    public void testConstructorN()
    {
        SlotMachine machine = new SlotMachine(5);

        assertEquals(5, machine.configuration().length);
        assertEquals(25, machine.symbols().length);

        String[] symbols = machine.symbols();
        assertEquals(symbols[0], symbols[5]);
        assertEquals(symbols[1], symbols[6]);
        assertEquals(symbols[2], symbols[7]);
        assertEquals(symbols[3], symbols[8]);
        assertEquals(symbols[4], symbols[9]);
    }

    public void testInvalidConstructorN()
    {
        try
        {
            new SlotMachine(2);
            fail("Se esperaba una excepción.");
        }
        catch (IllegalArgumentException expected)
        {
            assertTrue(true);
        }
    }
}
