/**
 * Representa un símbolo de la máquina tragamonedas.
 * Cada símbolo se identifica mediante un color.
 *
 * @version 2.0
 */
public class Symbol
{
    private String color;
    private Circle figure;
    private boolean visible;

    /**
     * Construye un símbolo con el color indicado.
     *
     * @param color el color del símbolo
     */
    public Symbol(String color)
    {
        this.color = color;
        figure = new Circle();
        figure.changeSize(60);
        figure.moveHorizontal(35);
        figure.moveVertical(145);
        figure.changeColor(color);
        visible = false;
    }

    public String getColor()
    {
        return color;
    }

    public void makeVisible()
    {
        figure.makeVisible();
        visible = true;
    }

    public void makeInvisible()
    {
        figure.makeInvisible();
        visible = false;
    }

    public void moveHorizontal(int distance)
    {
        figure.moveHorizontal(distance);
    }

    public void moveVertical(int distance)
    {
        figure.moveVertical(distance);
    }

    public boolean isVisible()
    {
        return visible;
    }
}
