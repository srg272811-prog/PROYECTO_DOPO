import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de la máquina tragamonedas.
 */
public class SlotMachineContestTest3
{
    /**
     * Verifica la creación básica de la máquina.
     */
    @Test
    public void testCreation()
    {
        SlotMachine machine = new SlotMachine(3);

        assertNotNull(machine);
        assertEquals(3, machine.configuration().length);
        assertEquals(9, machine.symbols().length);
    }

    /**
     * Verifica que una máquina pueda tener más de tres ruedas.
     */
    @Test
    public void testAddWheel()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.addWheel(4);

        assertEquals(4, machine.configuration().length);
        assertTrue(machine.ok());
    }

    /**
     * Verifica que se pueda eliminar una rueda.
     */
    @Test
    public void testDeleteWheel()
    {
        SlotMachine machine = new SlotMachine(4);

        machine.delWheel(4);

        assertEquals(3, machine.configuration().length);
        assertTrue(machine.ok());
    }

    /**
     * Verifica que no se pueda eliminar una rueda
     * cuando quedan solamente tres.
     */
    @Test
    public void testMinimumWheels()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.delWheel(1);

        assertFalse(machine.ok());
        assertEquals(3, machine.configuration().length);
    }

    /**
     * Verifica que se pueda bloquear y desbloquear una rueda.
     */
    @Test
    public void testLockUnlock()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.lock(1);

        machine.spin(1, 1);

        assertFalse(machine.ok());

        machine.unlock(1);

        machine.spin(1, 1);

        assertTrue(machine.ok());
    }

    /**
     * Verifica que una rueda pueda girar.
     */
    @Test
    public void testSpinOneWheel()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.spin(1, 1);

        assertTrue(machine.ok());
    }

    /**
     * Verifica que todas las ruedas puedan girar.
     */
    @Test
    public void testSpinAllWheels()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.spin();

        assertTrue(machine.ok());
    }

    /**
     * Verifica que se pueda colocar una configuración específica.
     */
    @Test
    public void testSpinConfiguration()
    {
        SlotMachine machine = new SlotMachine(3);

        String[] symbols = {
            "red",
            "blue",
            "green"
        };

        machine.spin(symbols);

        assertTrue(machine.ok());
        assertArrayEquals(symbols, machine.configuration());
    }

    /**
     * Verifica el conteo de símbolos diferentes.
     */
    @Test
    public void testDistinctSymbols()
    {
        SlotMachine machine = new SlotMachine(3);

        String[] symbols = {
            "red",
            "red",
            "red"
        };

        machine.spin(symbols);

        assertEquals(1, machine.distinctSymbols());
    }

    /**
     * Verifica que una configuración con todos
     * los símbolos iguales produzca jackpot.
     */
    @Test
    public void testJackpot()
    {
        SlotMachine machine = new SlotMachine(3);

        String[] symbols = {
            "red",
            "red",
            "red"
        };

        machine.spin(symbols);

        assertTrue(machine.isJackpot());
    }

    /**
     * Verifica que una configuración con símbolos
     * diferentes no produzca jackpot.
     */
    @Test
    public void testNoJackpot()
    {
        SlotMachine machine = new SlotMachine(3);

        String[] symbols = {
            "red",
            "blue",
            "green"
        };

        machine.spin(symbols);

        assertFalse(machine.isJackpot());
    }

    /**
     * Verifica agregar y eliminar símbolos.
     */
    @Test
    public void testAddDeleteSymbol()
    {
        SlotMachine machine = new SlotMachine(3);

        int before = machine.symbols().length;

        machine.addSymbol(1, "black");

        assertEquals(before + 3, machine.symbols().length);

        machine.delSymbol("black");

        assertEquals(before, machine.symbols().length);
    }

    /**
     * Verifica una posición inválida de rueda.
     */
    @Test
    public void testInvalidWheel()
    {
        SlotMachine machine = new SlotMachine(3);

        machine.spin(10, 1);

        assertFalse(machine.ok());
    }
}