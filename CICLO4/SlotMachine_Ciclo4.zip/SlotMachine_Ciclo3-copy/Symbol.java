/**
 * Representa un símbolo de la máquina tragamonedas.
 * Cada símbolo se identifica mediante un color.
 *
 * @version 2.0
 */
public class Symbol
{
    private String color;
    private Circle figure;
    private boolean visible;

    /**
     * Construye un símbolo con el color indicado.
     *
     * @param color el color del símbolo
     */
    public Symbol(String color)
    {
        this.color = color;
        figure = new Circle();
        figure.changeSize(60);
        figure.moveHorizontal(35);
        figure.moveVertical(145);
        figure.changeColor(color);
        visible = false;
    }

    /** Acción ejecutada cuando este símbolo es seleccionado por una rueda. */
    public void onSelected()
    {
        // El símbolo normal no cambia al ser seleccionado.
    }

    /** Cambia el tamaño de la figura visual.
     * @param size nuevo tamaño, en píxeles
     */
    protected void setFigureSize(int size)
    {
        figure.changeSize(Math.max(1, size));
    }

    /** Cambia el color visual de la figura.
     * @param color nuevo color
     */
    protected void setFigureColor(String color)
    {
        figure.changeColor(color);
    }

    public String getColor()
    {
        return color;
    }

    public void makeVisible()
    {
        figure.makeVisible();
        visible = true;
    }

    public void makeInvisible()
    {
        figure.makeInvisible();
        visible = false;
    }

    public void moveHorizontal(int distance)
    {
        figure.moveHorizontal(distance);
    }

    public void moveVertical(int distance)
    {
        figure.moveVertical(distance);
    }

    public boolean isVisible()
    {
        return visible;
    }
}
