import java.util.ArrayList;
import java.util.Random;

/**
 * Simula una máquina tragamonedas formada por varias ruedas.
 *
 * En el Ciclo 3 se agrega el constructor SlotMachine(n), que crea
 * exactamente n ruedas y n símbolos por rueda.
 *
 * @version 2.0
 */
public class SlotMachine
{
    public static final int MIN_WHEELS = 3;
    public static final int MAX_WHEELS = 50;

    private ArrayList<Wheel> wheels;
    private boolean visible;
    private boolean lastOperation;
    private Rectangle machineBody;
    private Rectangle topPanel;
    private Rectangle bottomPanel;
    private Rectangle lever;
    private Circle leverKnob;
    private ArrayList<Rectangle> windowFrames;
    private ArrayList<Rectangle> windows;
    private boolean jackpot;

    /**
     * Construye una máquina con el mínimo permitido de ruedas.
     */
    public SlotMachine()
    {
        this(MIN_WHEELS);
    }

    /**
     * Construye una máquina con n ruedas y n símbolos distintos.
     *
     * @param n número de ruedas y de símbolos
     * @throws IllegalArgumentException si n no está entre 3 y 50
     */
    public SlotMachine(int n)
    {
        if (n < MIN_WHEELS || n > MAX_WHEELS)
        {
            throw new IllegalArgumentException(
                "El número de ruedas debe estar entre 3 y 50."
            );
        }

        wheels = new ArrayList<Wheel>();
        windowFrames = new ArrayList<Rectangle>();
        windows = new ArrayList<Rectangle>();
        visible = false;
        lastOperation = true;
        jackpot = false;

        createMachineBody(n);

        for (int i = 1; i <= n; i++)
        {
            addWheel(i);
        }

        String[] colors = createColors(n);
        for (int i = 1; i < n; i++)
        {
            addSymbol(i + 1, colors[i]);
        }

        randomizeConfiguration(n);
    }

    /**
     * Crea la parte visual principal de la máquina.
     */
    private void createMachineBody(int n)
    {
        int width = Math.max(310, n * 90 + 40);

        machineBody = new Rectangle();
        machineBody.changeSize(220, width);
        machineBody.changeColor("red");
        machineBody.moveHorizontal(-50);
        machineBody.moveVertical(65);

        topPanel = new Rectangle();
        topPanel.changeSize(40, width - 20);
        topPanel.changeColor("black");
        topPanel.moveHorizontal(-40);
        topPanel.moveVertical(75);

        bottomPanel = new Rectangle();
        bottomPanel.changeSize(35, width - 20);
        bottomPanel.changeColor("black");
        bottomPanel.moveHorizontal(-40);
        bottomPanel.moveVertical(255);

        /*
         * Se conservan los objetos de la palanca para no cambiar
         * la estructura de la clase, pero se colocan fuera de la
         * zona visible de la máquina.
         */
        lever = new Rectangle();
        lever.changeSize(1, 1);
        lever.changeColor("black");
        lever.moveHorizontal(-1000);
        lever.moveVertical(-1000);

        leverKnob = new Circle();
        leverKnob.changeSize(1);
        leverKnob.changeColor("black");
        leverKnob.moveHorizontal(-1000);
        leverKnob.moveVertical(-1000);
    }

    /**
     * Crea los marcos y fondos de las ventanas visuales.
     */
    private void createWindow(int position)
    {
        int xDistance = -25 + (position - 1) * 90;

        Rectangle frame = new Rectangle();
        frame.changeSize(84, 72);
        frame.changeColor("orange");
        frame.moveHorizontal(xDistance + 3);
        frame.moveVertical(132);

        Rectangle window = new Rectangle();
        window.changeSize(76, 64);
        window.changeColor("black");
        window.moveHorizontal(xDistance + 7);
        window.moveVertical(136);

        windowFrames.add(frame);
        windows.add(window);
    }

    /**
     * Genera n colores distintos. Se usan colores con nombre para los
     * primeros símbolos y colores hexadecimales para permitir n hasta 50.
     */
    private String[] createColors(int n)
    {
        String[] colors = new String[n];

        String[] baseColors = {
            "red", "blue", "green", "yellow",
            "magenta", "cyan", "orange", "pink"
        };

        for (int i = 0; i < n; i++)
        {
            if (i < baseColors.length)
            {
                colors[i] = baseColors[i];
            }
            else
            {
                int red = (i * 73 + 50) % 256;
                int green = (i * 151 + 80) % 256;
                int blue = (i * 197 + 110) % 256;

                colors[i] = String.format(
                    "#%02X%02X%02X", red, green, blue
                );
            }
        }

        return colors;
    }

    /**
     * Aleatoriza la configuración inicial.
     */
    private void randomizeConfiguration(int n)
    {
        Random random = new Random();

        for (int i = 1; i <= n; i++)
        {
            int steps = random.nextInt(n);
            if (steps > 0)
            {
                spin(i, steps);
            }
        }

        lastOperation = true;
    }

    /**
     * Intercambia dos ruedas de la máquina.
     *
     * @param wheel1 posición de la primera rueda
     * @param wheel2 posición de la segunda rueda
     */
    public void swap(int wheel1, int wheel2)
    {
        if (wheel1 < 1 || wheel1 > wheels.size() ||
            wheel2 < 1 || wheel2 > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }

        Wheel first = wheels.get(wheel1 - 1);
        Wheel second = wheels.get(wheel2 - 1);
        if (first instanceof RebelWheel || second instanceof RebelWheel)
        {
            lastOperation = false;
            showError("Las ruedas rebel no se pueden intercambiar.");
            return;
        }

        wheels.set(wheel1 - 1, second);
        wheels.set(wheel2 - 1, first);

        organizeWheels();
        lastOperation = true;
    }

    /**
     * Bloquea una rueda.
     *
     * @param wheel posición de la rueda
     */
    public void lock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else
        {
            if (wheels.get(wheel - 1) instanceof RebelWheel)
            {
                lastOperation = false;
                showError("Una rueda rebel no se puede bloquear.");
                return;
            }
            wheels.get(wheel - 1).lock();
            lastOperation = true;
        }
    }

    /**
     * Desbloquea una rueda.
     *
     * @param wheel posición de la rueda
     */
    public void unlock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else
        {
            wheels.get(wheel - 1).unlock();
            lastOperation = true;
        }
    }

    /**
     * Gira una rueda o sincroniza una rueda lefty.
     *
     * @param wheel posición de la rueda, comenzando en 1
     * @param steps cantidad de pasos; negativos giran hacia atrás
     */
    public void spin(int wheel, int steps)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }

        Wheel selectedWheel = wheels.get(wheel - 1);
        if (selectedWheel.isLocked())
        {
            lastOperation = false;
            showError("Wheel is locked");
            return;
        }

        if (selectedWheel instanceof LeftyWheel)
        {
            // Una lefty no gira por cuenta propia: copia el símbolo
            // actual de la rueda inmediatamente a su izquierda.
            synchronizeLefty(wheel, true);
        }
        else
        {
            int direction = steps < 0 ? -1 : 1;
            for (int i = 0; i < Math.abs(steps); i++)
            {
                if (visible)
                {
                    selectedWheel.makeInvisible();
                }

                selectedWheel.spin(direction);
                Symbol current = selectedWheel.getCurrentSymbol();
                if (current != null)
                {
                    current.onSelected();
                }

                // Una lefty situada inmediatamente a la derecha copia
                // cada nuevo estado, no solamente el estado final.
                if (wheel < wheels.size() &&
                    wheels.get(wheel) instanceof LeftyWheel)
                {
                    synchronizeLefty(wheel + 1, true);
                }

                if (visible)
                {
                    selectedWheel.makeVisible();
                    Canvas.getCanvas().wait(70);
                }
            }
        }

        lastOperation = true;
    }

    /**
     * Sincroniza una rueda lefty con la rueda inmediatamente a su izquierda.
     * Solo ejecuta el comportamiento del símbolo cuando cambia la selección.
     *
     * @param leftyPosition posición de la lefty, comenzando en 1
     * @param triggerSelection indica si se debe notificar la nueva selección
     */
    private void synchronizeLefty(int leftyPosition, boolean triggerSelection)
    {
        if (leftyPosition <= 1 || leftyPosition > wheels.size())
        {
            return;
        }

        Wheel lefty = wheels.get(leftyPosition - 1);
        if (!(lefty instanceof LeftyWheel) || lefty.isLocked())
        {
            return;
        }

        Wheel leftWheel = wheels.get(leftyPosition - 2);
        Symbol leftSymbol = leftWheel.getCurrentSymbol();
        if (leftSymbol == null)
        {
            return;
        }

        Symbol oldSymbol = lefty.getCurrentSymbol();
        boolean changed = oldSymbol == null ||
            !oldSymbol.getColor().equals(leftSymbol.getColor());
        if (changed && visible)
        {
            lefty.makeInvisible();
        }
        if (lefty.placeSymbolByColor(leftSymbol.getColor()) &&
            changed && triggerSelection)
        {
            Symbol selected = lefty.getCurrentSymbol();
            if (selected != null)
            {
                selected.onSelected();
            }
        }
        if (changed && visible)
        {
            lefty.makeVisible();
        }
    }

    /**
     * Deja la máquina en la configuración indicada.
     *
     * @param setSymbols colores deseados, uno por rueda
     */
    public void spin(String[] setSymbols)
    {
        if (setSymbols == null || setSymbols.length != wheels.size())
        {
            lastOperation = false;
            showError("Invalid configuration");
            return;
        }

        for (int i = 0; i < wheels.size(); i++)
        {
            Wheel currentWheel = wheels.get(i);
            int position = -1;

            for (int j = 0; j < currentWheel.size(); j++)
            {
                Symbol symbol = currentWheel.getSymbol(j);

                if (symbol.getColor().equals(setSymbols[i]))
                {
                    position = j;
                    break;
                }
            }

            if (position == -1 || currentWheel.isLocked())
            {
                lastOperation = false;
                showError("Invalid configuration");
                return;
            }
        }

        for (int i = 0; i < wheels.size(); i++)
        {
            Wheel currentWheel = wheels.get(i);
            int position = -1;

            for (int j = 0; j < currentWheel.size(); j++)
            {
                if (currentWheel.getSymbol(j).getColor().equals(setSymbols[i]))
                {
                    position = j;
                    break;
                }
            }

            currentWheel.placeSymbol(position);
        }

        lastOperation = true;
    }

    /**
     * Agrega una rueda respetando el mínimo de tres ruedas.
     *
     * @param pos posición donde se agregará
     */
    public void addWheel(int pos)
    {
        addWheel(pos, "normal");
    }

    /** Agrega una rueda del tipo solicitado.
     * @param pos posición de inserción, comenzando en 1
     * @param type tipo: normal, lefty o rebel
     */
    public void addWheel(int pos, String type)
    {
        if (type == null || !(type.equalsIgnoreCase("normal") ||
            type.equalsIgnoreCase("lefty") || type.equalsIgnoreCase("rebel")))
        {
            lastOperation = false;
            showError("Tipo de rueda desconocido.");
            return;
        }
        if (wheels.size() >= MAX_WHEELS)
        {
            lastOperation = false;
            showError("Maximum number of wheels reached.");
            return;
        }
    
        Wheel newWheel;
        if (type.equalsIgnoreCase("lefty")) newWheel = new LeftyWheel();
        else if (type.equalsIgnoreCase("rebel")) newWheel = new RebelWheel();
        else newWheel = new Wheel();

        // Todas las ruedas deben tener los mismos símbolos y colores para
        // que swap, spin(String[]) y lefty funcionen de forma coherente.
        if (wheels.isEmpty())
        {
            newWheel.addSymbol(new Symbol("red"));
        }
        else
        {
            Wheel template = wheels.get(0);
            for (int i = 0; i < template.size(); i++)
            {
                newWheel.addSymbol(copySymbol(template.getSymbol(i)));
            }
        }
    
        if (pos < 1)
        {
            pos = 1;
        }
    
        if (pos > wheels.size() + 1)
        {
            pos = wheels.size() + 1;
        }
    
        int insertionIndex = pos - 1;
    
        // Desplazar las ventanas que ya estaban a la derecha.
        for (int i = windowFrames.size() - 1;
             i >= insertionIndex; i--)
        {
            windowFrames.get(i).moveHorizontal(90);
            windows.get(i).moveHorizontal(90);
        }
    
        wheels.add(insertionIndex, newWheel);
    
        createWindow(pos);
    
        organizeWheels();
    
        // Ajustar el tamaño de la máquina.
        resizeMachine();
        organizeVisualOrder();
    
        lastOperation = true;
    }

    /** Copia el tipo y color de un símbolo al construir una rueda nueva. */
    private Symbol copySymbol(Symbol original)
    {
        if (original instanceof EphemeralSymbol)
        {
            return new EphemeralSymbol(original.getColor());
        }
        if (original instanceof ShySymbol)
        {
            return new ShySymbol(original.getColor());
        }
        if (original instanceof GlowingSymbol)
        {
            return new GlowingSymbol(original.getColor());
        }
        return new Symbol(original.getColor());
    }

    /**
     * Elimina una rueda sin permitir que la máquina tenga menos de tres.
     *
     * @param pos posición de la rueda
     */
    public void delWheel(int pos)
    {
        if (wheels.size() <= MIN_WHEELS)
        {
            showError("La máquina debe tener mínimo 3 ruedas.");
            lastOperation = false;
            return;
        }
    
        if (pos < 1 || pos > wheels.size())
        {
            showError("Invalid wheel position");
            lastOperation = false;
            return;
        }
    
        if (wheels.get(pos - 1) instanceof RebelWheel)
        {
            lastOperation = false;
            showError("Una rueda rebel no se puede eliminar.");
            return;
        }

        /*
         * Primero obtenemos la rueda que vamos a eliminar
         * y la hacemos invisible.
         */
        Wheel removedWheel = wheels.get(pos - 1);
    
        if (visible)
        {
            removedWheel.makeInvisible();
        }
    
        wheels.remove(pos - 1);
    
        int removedIndex = pos - 1;
    
        Rectangle frame = windowFrames.remove(removedIndex);
        Rectangle window = windows.remove(removedIndex);
    
        frame.makeInvisible();
        window.makeInvisible();
    
        /*
         * Mover las ventanas que estaban después
         * de la rueda eliminada.
         */
        for (int i = removedIndex;
             i < windowFrames.size(); i++)
        {
            windowFrames.get(i).moveHorizontal(-90);
            windows.get(i).moveHorizontal(-90);
        }
    
        organizeWheels();
    
        // Reducir nuevamente el tamaño de la máquina.
        resizeMachine();
        organizeVisualOrder();
    
        lastOperation = true;
    }

    /**
     * Indica si la última operación fue exitosa.
     *
     * @return true si fue exitosa
     */
    public boolean ok()
    {
        return lastOperation;
    }

    /**
     * Agrega un símbolo del color indicado a todas las ruedas.
     *
     * @param pos posición del símbolo
     * @param color color del símbolo
     */
    public void addSymbol(int pos, String color)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        for (Wheel wheel : wheels)
        {
            Symbol newSymbol = new Symbol(color);

            int position = pos;

            if (position < 1)
            {
                position = 1;
            }

            if (position > wheel.size() + 1)
            {
                position = wheel.size() + 1;
            }

            wheel.addSymbol(position - 1, newSymbol);
        }

        lastOperation = true;
    }

    /** Agrega a todas las ruedas un símbolo del tipo solicitado.
     * @param pos posición de inserción
     * @param type tipo: normal, ephemeral, shy o glowing
     * @param color color del símbolo
     */
    public void addSymbol(int pos, String type, String color)
    {
        if (type == null || color == null ||
            !(type.equalsIgnoreCase("normal") || type.equalsIgnoreCase("ephemeral") ||
              type.equalsIgnoreCase("shy") || type.equalsIgnoreCase("glowing")))
        {
            lastOperation = false;
            showError("Tipo de símbolo desconocido o color vacío.");
            return;
        }
        for (Wheel wheel : wheels)
        {
            Symbol symbol;
            if (type.equalsIgnoreCase("ephemeral")) symbol = new EphemeralSymbol(color);
            else if (type.equalsIgnoreCase("shy")) symbol = new ShySymbol(color);
            else if (type.equalsIgnoreCase("glowing")) symbol = new GlowingSymbol(color);
            else symbol = new Symbol(color);
            int position = Math.max(1, Math.min(pos, wheel.size() + 1));
            wheel.addSymbol(position - 1, symbol);
        }
        lastOperation = true;
    }

    /** Retorna el tipo de rueda en una posición.
     * @param pos posición comenzando en 1
     * @return tipo de rueda o cadena vacía si la posición es inválida
     */
    public String wheelType(int pos)
    {
        if (pos < 1 || pos > wheels.size()) return "";
        return wheels.get(pos - 1).getType();
    }

    /**
     * Elimina de todas las ruedas el símbolo indicado.
     *
     * @param symbol color del símbolo
     */
    public void delSymbol(String symbol)
    {
        boolean removed = false;

        for (Wheel wheel : wheels)
        {
            if (wheel.delSymbol(symbol))
            {
                removed = true;
            }
        }

        if (!removed)
        {
            showError("No se encontró el símbolo.");
        }

        lastOperation = removed;
    }

    /**
     * Coloca un símbolo como visible en una rueda.
     *
     * @param wheel posición de la rueda
     * @param symbol posición del símbolo
     */
    public void placeSymbol(int wheel, int symbol)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }

        Wheel selectedWheel = wheels.get(wheel - 1);

        if (selectedWheel.size() == 0)
        {
            showError("La rueda no tiene símbolos.");
            lastOperation = false;
            return;
        }

        if (symbol < 1 || symbol > selectedWheel.size())
        {
            lastOperation = false;
            showError("Invalid symbol position");
            return;
        }

        if (visible)
        {
            selectedWheel.makeInvisible();
        }

        lastOperation = selectedWheel.placeSymbol(symbol - 1);

        if (visible)
        {
            selectedWheel.makeVisible();
        }
    }

    /**
     * Gira todas las ruedas un paso.
     */
    public void spin()
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas para girar.");
            lastOperation = false;
            return;
        }

        for (int i = 0; i < wheels.size(); i++)
        {
            Wheel wheel = wheels.get(i);
            if (wheel.isLocked())
            {
                continue;
            }

            if (wheel instanceof LeftyWheel)
            {
                // Se sincroniza al llegar a la lefty, una sola vez.
                synchronizeLefty(i + 1, true);
                continue;
            }

            if (visible)
            {
                wheel.makeInvisible();
            }

            wheel.spin();
            Symbol current = wheel.getCurrentSymbol();
            if (current != null)
            {
                current.onSelected();
            }

            if (visible)
            {
                wheel.makeVisible();
            }
        }

        lastOperation = true;
    }

    /** Acceso de paquete para verificar el estado de símbolos en pruebas. */
    Wheel wheelAt(int position)
    {
        if (position < 1 || position > wheels.size())
        {
            return null;
        }
        return wheels.get(position - 1);
    }

    /**
     * Retorna la configuración actual.
     *
     * @return colores visibles de izquierda a derecha
     */
    public String[] configuration()
    {
        String[] result = new String[wheels.size()];

        for (int i = 0; i < wheels.size(); i++)
        {
            Symbol current = wheels.get(i).getCurrentSymbol();
            result[i] = current == null ? null : current.getColor();
        }

        return result;
    }

    /**
     * Retorna todos los símbolos de la máquina.
     *
     * @return arreglo de colores
     */
    public String[] symbols()
    {
        ArrayList<String> result = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            for (int i = 0; i < wheel.size(); i++)
            {
                result.add(wheel.getSymbol(i).getColor());
            }
        }

        return result.toArray(new String[result.size()]);
    }

    /**
     * Cuenta los símbolos diferentes visibles.
     *
     * @return número de símbolos diferentes
     */
    public int distinctSymbols()
    {
        ArrayList<String> different = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            Symbol symbol = wheel.getCurrentSymbol();

            if (symbol != null && !different.contains(symbol.getColor()))
            {
                different.add(symbol.getColor());
            }
        }

        return different.size();
    }

    /**
     * Determina si existe jackpot.
     *
     * @return true si todas las ruedas muestran el mismo símbolo
     */
    public boolean isJackpot()
    {
        if (wheels.size() < MIN_WHEELS)
        {
            jackpot = false;
            machineBody.changeColor("red");
            organizeVisualOrder();
            lastOperation = false;
            return false;
        }
    
        String[] currentConfiguration = configuration();
    
        String firstSymbol = currentConfiguration[0];
    
        if (firstSymbol == null)
        {
            jackpot = false;
            machineBody.changeColor("red");
            organizeVisualOrder();
            lastOperation = false;
            return false;
        }
    
        for (int i = 1; i < currentConfiguration.length; i++)
        {
            if (currentConfiguration[i] == null ||
                !currentConfiguration[i].equals(firstSymbol))
            {
                jackpot = false;
                machineBody.changeColor("red");
                organizeVisualOrder();
                lastOperation = true;
                return false;
            }
        }
    
        jackpot = true;
        machineBody.changeColor("green");
    
        /*
         * Volvemos a poner las ventanas y ruedas
         * por encima del cuerpo de la máquina.
         */
        organizeVisualOrder();
    
        lastOperation = true;
        return true;
    }

    /**
     * Hace visible la máquina completa.
     */
    public void makeVisible()
    {
        visible = true;

        machineBody.makeVisible();
        topPanel.makeVisible();
        bottomPanel.makeVisible();
        lever.makeVisible();
        leverKnob.makeVisible();

        for (Rectangle frame : windowFrames)
        {
            frame.makeVisible();
        }

        for (Rectangle window : windows)
        {
            window.makeVisible();
        }

        for (Wheel wheel : wheels)
        {
            wheel.makeVisible();
        }

        lastOperation = true;
    }

    /**
     * Oculta la máquina completa.
     */
    public void makeInvisible()
    {
        visible = false;
        machineBody.makeInvisible();
        topPanel.makeInvisible();
        bottomPanel.makeInvisible();
        lever.makeInvisible();
        leverKnob.makeInvisible();

        for (Rectangle frame : windowFrames)
        {
            frame.makeInvisible();
        }
        for (Rectangle window : windows)
        {
            window.makeInvisible();
        }
        for (Wheel wheel : wheels)
        {
            wheel.makeInvisible();
        }
        lastOperation = true;
    }

    /**
     * Organiza las ruedas de izquierda a derecha.
     */
    private void organizeWheels()
    {
        for (int i = 0; i < wheels.size(); i++)
        {
            wheels.get(i).setHorizontalPosition(i * 90);
        }
    }
    
    /**
     * Restaura el orden visual: cuerpo al fondo, ventanas encima y ruedas al frente.
     */
    private void organizeVisualOrder()
    {
        if (visible)
        {
            machineBody.makeVisible();
            topPanel.makeVisible();
            bottomPanel.makeVisible();
            for (Rectangle frame : windowFrames)
            {
                frame.makeVisible();
            }
            for (Rectangle window : windows)
            {
                window.makeVisible();
            }
            for (Wheel wheel : wheels)
            {
                wheel.makeVisible();
            }
        }
    }

    /**
     * Ajusta el tamaño visual de la máquina al número actual de ruedas.
     */
    private void resizeMachine()
    {
        int width = Math.max(310, wheels.size() * 90 + 40);
    
        machineBody.changeSize(220, width);
        topPanel.changeSize(40, width - 20);
        bottomPanel.changeSize(35, width - 20);
    }
    
    private void showError(String message)
    {
        if (visible)
        {
            javax.swing.JOptionPane.showMessageDialog(null, message);
        }
    }
}