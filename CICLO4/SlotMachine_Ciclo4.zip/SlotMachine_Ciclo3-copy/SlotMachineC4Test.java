import junit.framework.*;

/** Pruebas unitarias de los requisitos del ciclo 4. */
public class SlotMachineC4Test extends TestCase
{
    public void testLeftyCopiesLeftWheelWhenSpunWithSteps()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(2, "lefty");
        machine.placeSymbol(1, 2);
        machine.spin(2, 1);
        assertEquals(machine.configuration()[0], machine.configuration()[1]);
        assertTrue(machine.ok());
    }

    public void testLeftyCopiesLeftWheelDuringGeneralSpin()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(2, "lefty");
        machine.spin();
        assertEquals(machine.configuration()[0], machine.configuration()[1]);
        assertTrue(machine.ok());
    }

    public void testRebelCannotBeLocked()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(4, "rebel");
        machine.lock(4);
        assertFalse(machine.ok());
        assertFalse(machine.wheelAt(4).isLocked());
    }

    public void testRebelCannotBeDeleted()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(4, "rebel");
        machine.delWheel(4);
        assertFalse(machine.ok());
        assertEquals(4, machine.configuration().length);
        assertEquals("rebel", machine.wheelType(4));
    }

    public void testRebelCannotBeSwapped()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(4, "rebel");
        machine.swap(1, 4);
        assertFalse(machine.ok());
        assertEquals("rebel", machine.wheelType(4));
    }

    public void testEphemeralShrinksOnlyWhenSelectedAndKeepsSize()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "ephemeral", "black");
        EphemeralSymbol symbol = (EphemeralSymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);

        machine.spin(1, 1); // selecciona el efímero
        assertEquals(50, symbol.getCurrentSize());
        machine.spin(1, 1); // selecciona otro símbolo
        assertEquals(50, symbol.getCurrentSize());
        machine.spin(1, machine.wheelAt(1).size() - 1); // vuelve al efímero
        assertEquals(40, symbol.getCurrentSize());
    }

    public void testEphemeralShrinksDuringGeneralSpin()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "ephemeral", "black");
        EphemeralSymbol symbol = (EphemeralSymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);
        machine.spin();
        assertEquals(50, symbol.getCurrentSize());
    }

    public void testEphemeralDoesNotShrinkBelowOne()
    {
        EphemeralSymbol symbol = new EphemeralSymbol("black");
        for (int i = 0; i < 20; i++) symbol.onSelected();
        assertEquals(1, symbol.getCurrentSize());
    }

    public void testShyAlternatesWhenSelectedWithSteps()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "shy", "white");
        ShySymbol symbol = (ShySymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);

        machine.spin(1, 1);
        assertTrue(symbol.isHidden());
        machine.spin(1, machine.wheelAt(1).size());
        assertFalse(symbol.isHidden());
    }

    public void testShyAlternatesDuringGeneralSpin()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "shy", "white");
        ShySymbol symbol = (ShySymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);
        machine.spin();
        assertTrue(symbol.isHidden());
    }

    public void testGlowingAlternatesBaseAndYellow()
    {
        GlowingSymbol symbol = new GlowingSymbol("blue");
        assertEquals("blue", symbol.getCurrentColor());
        symbol.onSelected();
        assertEquals("yellow", symbol.getCurrentColor());
        symbol.onSelected();
        assertEquals("blue", symbol.getCurrentColor());
    }

    public void testGlowingChangesWhenSelectedByGeneralSpin()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "glowing", "blue");
        GlowingSymbol symbol = (GlowingSymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);
        machine.spin();
        assertEquals("yellow", symbol.getCurrentColor());
    }

    public void testUnknownWheelTypeIsRejected()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(4, "unknown");
        assertFalse(machine.ok());
        assertEquals(3, machine.configuration().length);
    }
}
