/** Rueda rebelde, que no permite bloqueo, intercambio ni eliminación.
 * @author Proyecto DOPO
 * @version 1.0
 */
public class RebelWheel extends Wheel
{
    /** Construye una rueda rebelde vacía. */
    public RebelWheel() { super(); }
    /** Una rueda rebelde no se puede bloquear. */
    @Override public void lock() { unlock(); }
    /** Una rueda rebelde no se puede bloquear. */
    @Override public void unlock() { /* Siempre permanece desbloqueada. */ }
}
