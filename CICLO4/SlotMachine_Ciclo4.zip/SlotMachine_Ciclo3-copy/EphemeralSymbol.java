/**
 * Símbolo que reduce su tamaño en cada selección hasta convertirse en un punto.
 * @author Proyecto DOPO
 * @version 1.0
 */
public class EphemeralSymbol extends Symbol
{
    private int size;

    /** Construye un símbolo efímero de tamaño inicial 60.
     * @param color color visual del símbolo
     */
    public EphemeralSymbol(String color)
    {
        super(color);
        size = 60;
    }

    /** Reduce el tamaño del símbolo, sin bajar de un punto.
     */
    /** Retorna el tamaño actual del símbolo para comprobar que se conserva. */
    public int getCurrentSize()
    {
        return size;
    }

    @Override
    public void onSelected()
    {
        size = Math.max(1, size - 10);
        setFigureSize(size);
    }
}
