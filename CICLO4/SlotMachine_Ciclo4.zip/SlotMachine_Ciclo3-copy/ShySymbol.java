/**
 * Símbolo tímido que alterna su visibilidad cada vez que es seleccionado.
 */
public class ShySymbol extends Symbol
{
    private boolean hidden;

    public ShySymbol(String color)
    {
        super(color);
        hidden = false;
    }

    @Override
    public void onSelected()
    {
        // Solo cambia el estado lógico. La rueda aplica la visibilidad
        // cuando dibuja el símbolo; así seleccionar un símbolo en una
        // máquina oculta no abre una ventana gráfica inesperadamente.
        hidden = !hidden;
    }

    /** Indica si el símbolo tímido está en su estado oculto. */
    public boolean isHidden()
    {
        return hidden;
    }
}
