
/**
 * Representa una rueda especial que depende de la rueda situada
 * inmediatamente a su izquierda.
 *
 * Su sincronización se coordina desde SlotMachine, que conoce
 * la posición de cada rueda y puede consultar su estado.
 *
 * @author Proyecto DOPO
 * @version 2.0
 */
public class LeftyWheel extends Wheel
{
    /**
     * Construye una rueda lefty inicialmente vacía.
     */
    public LeftyWheel()
    {
        super();
    }

    /**
     * Identifica esta rueda como una rueda lefty.
     *
     * @return el tipo "lefty"
     */
    @Override
    public String getType()
    {
        return "lefty";
    }
}

