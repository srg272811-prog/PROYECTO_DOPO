/**
 * Tipo adicional: símbolo brillante que cambia de color en cada selección.
 * @author Proyecto DOPO
 * @version 1.0
 */
public class GlowingSymbol extends Symbol
{
    private boolean alternate;
    private String currentColor;

    /** Construye un símbolo brillante.
     * @param color color base
     */
    public GlowingSymbol(String color)
    {
        super(color);
        alternate = false;
        currentColor = color;
    }

    /** Alterna entre el color base y amarillo al seleccionarse.
     */
    /** Retorna el color visual actual para verificar el comportamiento. */
    public String getCurrentColor()
    {
        return currentColor;
    }

    @Override
    public void onSelected()
    {
        alternate = !alternate;
        currentColor = alternate ? "yellow" : getColor();
        setFigureColor(currentColor);
    }
}
