# Pruebas de aceptación — Ciclo 4

Estas pruebas cubren `lefty`, `rebel`, `ephemeral`, `shy` y el tipo nuevo `glowing`.

## 1. Lefty copia la rueda izquierda

1. Crear `SlotMachine machine = new SlotMachine(3)`.
2. Ejecutar `machine.addWheel(2, "lefty")`.
3. Ejecutar `machine.spin()` y comprobar que `machine.configuration()[0]` y `[1]` sean iguales.
4. En otra máquina, ejecutar `machine.spin(2, 1)` y comprobar que la rueda lefty copia el color de la rueda inmediatamente a su izquierda.

## 2. Rebel no se bloquea, elimina ni intercambia

1. Crear una máquina y ejecutar `addWheel(4, "rebel")`.
2. Ejecutar `lock(4)`: `ok()` debe ser `false` y `wheelAt(4).isLocked()` debe seguir en `false`.
3. Ejecutar `delWheel(4)`: `ok()` debe ser `false`, deben seguir existiendo cuatro ruedas y `wheelType(4)` debe seguir siendo `rebel`.
4. Ejecutar `swap(1, 4)`: `ok()` debe ser `false` y la rueda rebel debe seguir en la posición 4.

## 3. Ephemeral conserva y reduce el tamaño

1. Ejecutar `addSymbol(1, "ephemeral", "black")`.
2. Guardar el objeto de la primera rueda: `EphemeralSymbol symbol = (EphemeralSymbol) machine.wheelAt(1).getSymbol(0)`.
3. Colocar la rueda en el símbolo anterior al efímero y girar un paso. El tamaño debe pasar de 60 a 50.
4. Girar a un símbolo distinto: el tamaño del objeto efímero debe seguir en 50.
5. Volver a seleccionarlo: debe pasar a 40.
6. Comprobar que tras muchas selecciones no baja de 1.
7. Repetir la comprobación de selección con `spin()` general.

## 4. Shy alterna su estado sin abrir ventanas por sí solo

1. Ejecutar `addSymbol(1, "shy", "white")` y guardar la referencia al objeto `ShySymbol` de la primera rueda.
2. Colocar la rueda en el símbolo anterior al tímido y ejecutar `spin(1, 1)`: `isHidden()` debe ser `true`.
3. Avanzar hasta volver a seleccionarlo: `isHidden()` debe ser `false`.
4. Repetir con `spin()` general.
5. Para comprobar el aspecto visual, hacer visible la máquina con `makeVisible()` y repetir los giros. La rueda debe aplicar el estado del símbolo al dibujarlo.

`onSelected()` solo cambia el estado lógico de `ShySymbol`; la rueda decide cómo dibujarlo. Esto evita que una prueba o una selección en una máquina oculta abra inesperadamente una ventana gráfica.

## 5. Glowing alterna el color

1. Crear `GlowingSymbol symbol = new GlowingSymbol("blue")`.
2. Comprobar que `getCurrentColor()` devuelva `blue` inicialmente.
3. Ejecutar `onSelected()`: debe devolver `yellow`.
4. Ejecutarlo otra vez: debe volver a `blue`.
5. También se comprueba mediante `SlotMachine.spin()` general que seleccionar un `GlowingSymbol` cambie su color actual a amarillo.

## Ejecutar pruebas en BlueJ

1. Descomprimir el proyecto en una carpeta nueva y abrir `package.bluej`.
2. Pulsar **Compile**.
3. Ejecutar las pruebas JUnit de `SlotMachineC4Test` y `SlotMachineCC4Test`.
4. Ejecutar también las suites previas `SlotMachineC2Test`, `SlotMachineCC2Test`, `SlotMachineContestTest`, `SlotMachineContestCTest` y `SlotMachineContestTest3`.
5. Las pruebas de ciclo 4 deben comprobar los dos métodos de giro, no solo el giro general.
