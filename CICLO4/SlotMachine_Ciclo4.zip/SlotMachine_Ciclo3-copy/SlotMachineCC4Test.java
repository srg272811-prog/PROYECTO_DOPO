import junit.framework.*;

/** Pruebas compartidas de aceptación para los requisitos del ciclo 4. */
public class SlotMachineCC4Test extends TestCase
{
    public void testLeftyCopiesLeftNeighborInGeneralSpin()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addWheel(2, "lefty");
        machine.spin();
        assertEquals(machine.configuration()[0], machine.configuration()[1]);
    }

    public void testEphemeralChangesSizeOnGeneralSpin()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "ephemeral", "black");
        EphemeralSymbol symbol = (EphemeralSymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);
        machine.spin();
        assertEquals(50, symbol.getCurrentSize());
    }

    public void testShyTogglesWhenSelected()
    {
        SlotMachine machine = new SlotMachine(3);
        machine.addSymbol(1, "shy", "white");
        ShySymbol symbol = (ShySymbol) machine.wheelAt(1).getSymbol(0);
        machine.wheelAt(1).placeSymbol(machine.wheelAt(1).size() - 1);
        machine.spin(1, 1);
        assertTrue(symbol.isHidden());
        machine.spin(1, machine.wheelAt(1).size());
        assertFalse(symbol.isHidden());
    }

    public void testGlowingAlternatesColor()
    {
        GlowingSymbol symbol = new GlowingSymbol("blue");
        symbol.onSelected();
        assertEquals("yellow", symbol.getCurrentColor());
        symbol.onSelected();
        assertEquals("blue", symbol.getCurrentColor());
    }
}
