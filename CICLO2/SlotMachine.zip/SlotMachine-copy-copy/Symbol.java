
/**
 * Representa un símbolo de la máquina tragamonedas.
 * Cada símbolo se identifica mediante un color.
 *
 * @version 1.0
 */
public class Symbol
{
    private String color;
    private Circle figure;
    private boolean visible;

    /**
     * Construye un símbolo con el color indicado.
     *
     * @param color el color del símbolo
     */
    public Symbol(String color)
    {
        this.color = color;
        figure = new Circle();
        figure.changeSize(40);
        figure.changeColor(color);
        visible = false;
    }

    /**
     * Retorna el color del símbolo.
     *
     * @return el color del símbolo
     */
    public String getColor()
    {
        return color;
    }

    /**
     * Muestra el símbolo.
     */
    public void makeVisible()
    {
        figure.makeVisible();
        visible = true;
    }

    /**
     * Oculta el símbolo.
     */
    public void makeInvisible()
    {
        figure.makeInvisible();
        visible = false;
    }

    /**
     * Mueve el símbolo horizontalmente.
     *
     * @param distance cantidad que se moverá
     */
    public void moveHorizontal(int distance)
    {
        figure.moveHorizontal(distance);
    }

    /**
     * Mueve el símbolo verticalmente.
     *
     * @param distance cantidad que se moverá
     */
    public void moveVertical(int distance)
    {
        figure.moveVertical(distance);
    }

    /**
     * Indica si el símbolo está visible.
     *
     * @return true si está visible
     */
    public boolean isVisible()
    {
        return visible;
    }
}
