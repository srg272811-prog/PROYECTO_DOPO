import java.util.ArrayList;

/**
 * Simula una máquina tragamonedas formada por varias ruedas.
 *
 * @version 1.0
 */
public class SlotMachine
{
    private ArrayList<Wheel> wheels;
    private boolean visible;
    private boolean lastOperation;
    private Rectangle machineBody;
    private boolean jackpot;    

    public SlotMachine()
    {
        wheels = new ArrayList<Wheel>();
        visible = false;
        lastOperation = true;
        jackpot = false;
    
        machineBody = new Rectangle();
        machineBody.changeSize(300, 120);
        machineBody.changeColor("blue");
        machineBody.moveHorizontal(20);
        machineBody.moveVertical(100);
    }
    
    /**
     * Intercambia dos ruedas de la máquina.
     * Las posiciones externas comienzan en 1.
     *
     * @param wheel1 posición de la primera rueda
     * @param wheel2 posición de la segunda rueda
     */
    public void swap(int wheel1, int wheel2)
    {
        if (wheel1 < 1 || wheel1 > wheels.size() ||
            wheel2 < 1 || wheel2 > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
            return;
        }
    
        Wheel first = wheels.get(wheel1 - 1);
        Wheel second = wheels.get(wheel2 - 1);
    
        wheels.set(wheel1 - 1, second);
        wheels.set(wheel2 - 1, first);
    
        organizeWheels();
        lastOperation = true;
    }
    
    /**
     * Bloquea la rueda ubicada en la posición indicada.
     * Las posiciones externas comienzan en 1.
     * 
     * @param wheel posición de la rueda que se bloqueará
     */
    public void lock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else
        {
            wheels.get(wheel - 1).lock();
            lastOperation = true;
        }
    }
    
    /**
     * Desbloquea la rueda ubicada en la posición indicada.
     * Las posiciones externas comienzan en 1.
     * 
     * @param wheel posición de la rueda que se desbloqueará
     */
    public void unlock(int wheel)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else
        {
            wheels.get(wheel - 1).unlock();
            lastOperation = true;
        }
    }
    
    /**
     * Gira la rueda indicada la cantidad de pasos especificada.
     * Las posiciones externas comienzan en 1.
     *
     * @param wheel posición de la rueda que se girará
     * @param steps cantidad de pasos que girará la rueda
     */
    public void spin(int wheel, int steps)
    {
        if (wheel < 1 || wheel > wheels.size())
        {
            lastOperation = false;
            showError("Invalid wheel position");
        }
        else if (steps < 0)
        {
            lastOperation = false;
            showError("Invalid number of steps");
        }
        else if (wheels.get(wheel - 1).isLocked())
        {
            lastOperation = false;
            showError("Wheel is locked");
        }
        else
        {
            Wheel selectedWheel = wheels.get(wheel - 1);
    
            for (int i = 0; i < steps; i++)
            {
                if (visible)
                {
                    selectedWheel.makeInvisible();
                }
    
                selectedWheel.spin();
    
                if (visible)
                {
                    selectedWheel.makeVisible();
                    Canvas.getCanvas().wait(100);
                }
            }
    
            lastOperation = true;
        }
    }
    
    /**
     * Deja la máquina en la configuración de símbolos indicada.
     * Las posiciones de los símbolos corresponden a las posiciones de las ruedas.
     * 
     * @param setSymbols configuración de símbolos que tendrá la máquina
     */
    public void spin(String[] setSymbols)
    {
        if (setSymbols == null || setSymbols.length != wheels.size())
        {
            lastOperation = false;
            showError("Invalid configuration");
        }
        else
        {
            boolean valid = true;
    
            for (int i = 0; i < wheels.size(); i++)
            {
                Wheel currentWheel = wheels.get(i);
                int position = -1;
    
                for (int j = 0; j < currentWheel.size(); j++)
                {
                    Symbol symbol = currentWheel.getSymbol(j);
    
                    if (symbol.getColor().equals(setSymbols[i]))
                    {
                        position = j;
                        break;
                    }
                }
    
                if (position == -1 || currentWheel.isLocked())
                {
                    valid = false;
                    break;
                }
            }
    
            if (!valid)
            {
                lastOperation = false;
                showError("Invalid configuration");
            }
            else
            {
                for (int i = 0; i < wheels.size(); i++)
                {
                    Wheel currentWheel = wheels.get(i);
                    int position = -1;
    
                    for (int j = 0; j < currentWheel.size(); j++)
                    {
                        Symbol symbol = currentWheel.getSymbol(j);
    
                        if (symbol.getColor().equals(setSymbols[i]))
                        {
                            position = j;
                            break;
                        }
                    }
    
                    currentWheel.placeSymbol(position);
                }
    
                lastOperation = true;
            }
        }
    }
    
    /**
     * Adiciona una nueva rueda en la posición indicada.
     * Las posiciones externas comienzan en 1.
     *
     * @param pos posición donde se agregará la rueda
     */
    public void addWheel(int pos)
    {
        Wheel newWheel = new Wheel();
        Symbol newSymbol = new Symbol("red");
        newWheel.addSymbol(newSymbol);  

        if (pos < 1)
        {
            pos = 1;
        }

        if (pos > wheels.size() + 1)
        {
            pos = wheels.size() + 1;
        }

        wheels.add(pos - 1, newWheel);
        organizeWheels();
        lastOperation = true;
    }

    /**
     * Elimina la rueda ubicada en la posición indicada.
     * Las posiciones externas comienzan en 1.
     *
     * @param pos posición de la rueda que se eliminará
     */
    public void delWheel(int pos)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas para eliminar.");
            lastOperation = false;
            return;
        }
    
        if (pos < 1 || pos > wheels.size())
        {
            showError("Invalid wheel position");
            lastOperation = false;
            return;
        }
    
        wheels.remove(pos - 1);
        organizeWheels();
        lastOperation = true;
    }

    /**
     * Indica si la última operación se realizó correctamente.
     *
     * @return true si la última operación fue exitosa
     */
    public boolean ok()
    {
        return lastOperation;
    }

    /**
     * Agrega un símbolo del color indicado a todas las ruedas.
     *
     * @param pos posición donde se agregará el símbolo
     * @param color color que identifica el símbolo
     */
    public void addSymbol(int pos, String color)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        for (Wheel wheel : wheels)
        {
            Symbol newSymbol = new Symbol(color);

            int position = pos;

            if (position < 1)
            {
                position = 1;
            }

            if (position > wheel.size() + 1)
            {
                position = wheel.size() + 1;
            }

            wheel.addSymbol(position - 1, newSymbol);
        }

        lastOperation = true;
    }

    /**
     * Elimina de todas las ruedas el símbolo identificado
     * por el color indicado.
     *
     * @param symbol color del símbolo que se eliminará
     */
    public void delSymbol(String symbol)
    {
        boolean removed = false;

        for (Wheel wheel : wheels)
        {
            if (wheel.delSymbol(symbol))
            {
                removed = true;
            }
        }

        if (!removed)
        {
            showError("No se encontró el símbolo.");
        }

        lastOperation = removed;
    }

    /**
     * Coloca un símbolo como visible en la rueda indicada.
     *
     * @param wheel posición de la rueda
     * @param symbol posición del símbolo
     */
    public void placeSymbol(int wheel, int symbol)
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas en la máquina.");
            lastOperation = false;
            return;
        }

        if (wheel < 1)
        {
            wheel = 1;
        }

        if (wheel > wheels.size())
        {
            wheel = wheels.size();
        }

        Wheel selectedWheel = wheels.get(wheel - 1);

        if (selectedWheel.size() == 0)
        {
            showError("La rueda no tiene símbolos.");
            lastOperation = false;
            return;
        }

        if (symbol < 1)
        {
            symbol = 1;
        }

        if (symbol > selectedWheel.size())
        {
            symbol = selectedWheel.size();
        }

        if (visible)
        {
            selectedWheel.makeInvisible();
        }

        lastOperation = selectedWheel.placeSymbol(symbol - 1);

        if (visible)
        {
            selectedWheel.makeVisible();
        }
    }

    /**
     * Gira todas las ruedas de la máquina.
     */
    public void spin()
    {
        if (wheels.isEmpty())
        {
            showError("No hay ruedas para girar.");
            lastOperation = false;
            return;
        }

        boolean hasSymbols = false;

        for (Wheel wheel : wheels)
        {
            if (wheel.size() > 0)
            {
                if (visible)
                {
                    wheel.makeInvisible();
                }

                wheel.spin();

                if (visible)
                {
                    wheel.makeVisible();
                }

                hasSymbols = true;
            }
        }

        if (!hasSymbols)
        {
            showError("No hay símbolos para girar.");
        }

        lastOperation = hasSymbols;
    }

    /**
     * Retorna los símbolos visibles de todas las ruedas,
     * de izquierda a derecha.
     *
     * @return arreglo con los colores visibles
     */
    public String[] configuration()
    {
        String[] result = new String[wheels.size()];

        for (int i = 0; i < wheels.size(); i++)
        {
            Symbol current = wheels.get(i).getCurrentSymbol();

            if (current != null)
            {
                result[i] = current.getColor();
            }
            else
            {
                result[i] = null;
            }
        }

        lastOperation = true;
        return result;
    }

    /**
     * Retorna los símbolos de la máquina en el orden
     * en que aparecen en las ruedas.
     *
     * @return arreglo con los colores de los símbolos
     */
    public String[] symbols()
    {
        ArrayList<String> result = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            for (int i = 0; i < wheel.size(); i++)
            {
                Symbol symbol = wheel.getSymbol(i);
                result.add(symbol.getColor());
            }
        }

        lastOperation = true;
        return result.toArray(new String[result.size()]);
    }

    /**
     * Retorna la cantidad de símbolos diferentes
     * que existen en la máquina.
     *
     * @return cantidad de símbolos diferentes
     */
    public int distinctSymbols()
    {
        ArrayList<String> different = new ArrayList<String>();

        for (Wheel wheel : wheels)
        {
            for (int i = 0; i < wheel.size(); i++)
            {
                String color = wheel.getSymbol(i).getColor();

                if (!different.contains(color))
                {
                    different.add(color);
                }
            }
        }

        lastOperation = true;
        return different.size();
    }

    /**
     * Determina si la configuración actual es ganadora.
     * Hay jackpot cuando todas las ruedas muestran
     * el mismo símbolo.
     *
     * @return true si la configuración es ganadora
     */
    public boolean isJackpot()
    {
        if (wheels.isEmpty())
        {
            jackpot = false;
            machineBody.changeColor("red");
            lastOperation = false;
            return false;
        }
    
        String[] currentConfiguration = configuration();
    
        if (currentConfiguration.length == 0)
        {
            jackpot = false;
            machineBody.changeColor("red");
            lastOperation = false;
            return false;
        }
    
        String firstSymbol = currentConfiguration[0];
    
        if (firstSymbol == null)
        {
            jackpot = false;
            machineBody.changeColor("red");
            lastOperation = false;
            return false;
        }
    
        for (int i = 1; i < currentConfiguration.length; i++)
        {
            if (currentConfiguration[i] == null ||
                !currentConfiguration[i].equals(firstSymbol))
            {
                jackpot = false;
                machineBody.changeColor("red");
                lastOperation = true;
                return false;
            }
        }
    
        jackpot = true;
        machineBody.changeColor("green");
        lastOperation = true;
        return true;
    }

    public void makeVisible()
    {
        visible = true;
    
        machineBody.makeVisible();
    
        for (Wheel wheel : wheels)
        {
            wheel.makeVisible();
        }
    
        lastOperation = true;
    }

    public void makeInvisible()
    {
        machineBody.makeInvisible();
    
        for (Wheel wheel : wheels)
        {
            wheel.makeInvisible();
        }
    
        visible = false;
        lastOperation = true;
    }

    /**
     * Termina el simulador y oculta sus elementos.
     */
    public void exit()
    {
        makeInvisible();
        lastOperation = true;
    }
    
    /**
     * Organiza visualmente las ruedas de izquierda a derecha.
     */
    private void organizeWheels()
    {
        for (int i = 0; i < wheels.size(); i++)
        {
            wheels.get(i).setHorizontalPosition(i * 100);
        }
    }
    
    /**
     * Muestra un mensaje de error únicamente cuando
     * el simulador está visible.
     *
     * @param message mensaje que se mostrará
     */
    private void showError(String message)
    {
        if (visible)
        {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                message
            );
        }
    }
}