import junit.framework.*;

/**
 * Pruebas unitarias compartidas del Ciclo 2 de SlotMachine.
 *
 * @version 1.0
 */
public class SlotMachineCC2Test extends TestCase
{
    /**
     * Verifica que una rueda bloqueada no pueda girar
     * y que vuelva a girar después de desbloquearla.
     */
    public void testLockUnlockSRLF()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addSymbol(2, "blue");

        machine.placeSymbol(1, 1);
        machine.lock(1);
        machine.spin(1, 1);

        assertEquals("red", machine.configuration()[0]);

        machine.unlock(1);
        machine.spin(1, 1);

        assertEquals("blue", machine.configuration()[0]);
    }

    /**
     * Verifica que una máquina pueda establecer
     * una configuración determinada.
     */
    public void testConfigurationSRLF()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addWheel(2);

        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");

        String[] configuration = {"green", "blue"};

        machine.spin(configuration);

        String[] result = machine.configuration();

        assertEquals("green", result[0]);
        assertEquals("blue", result[1]);
    }
}