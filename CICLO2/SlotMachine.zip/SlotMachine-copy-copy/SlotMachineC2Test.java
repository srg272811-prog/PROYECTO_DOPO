import junit.framework.*;

/**
 * Pruebas unitarias para el Ciclo 2 de SlotMachine.
 *
 * @version 1.0
 */
public class SlotMachineC2Test extends TestCase
{
    /**
     * Verifica que dos ruedas puedan intercambiar sus posiciones.
     */
    public void testSwap()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addWheel(2);

        machine.addSymbol(2, "blue");

        String[] before = machine.configuration();

        machine.swap(1, 2);

        String[] after = machine.configuration();

        assertEquals(before[0], after[1]);
        assertEquals(before[1], after[0]);
    }

    /**
     * Verifica que una rueda pueda bloquearse y desbloquearse.
     */
    public void testLockUnlock()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addSymbol(2, "blue");

        machine.placeSymbol(1, 2);
        machine.lock(1);
        machine.spin(1, 1);

        assertEquals("blue", machine.configuration()[0]);

        machine.unlock(1);
        machine.spin(1, 1);

        assertEquals("red", machine.configuration()[0]);
    }

    /**
     * Verifica que una rueda avance la cantidad de pasos indicada.
     */
    public void testSpinSteps()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");

        machine.spin(1, 1);

        assertEquals("blue", machine.configuration()[0]);

        machine.spin(1, 2);

        assertEquals("red", machine.configuration()[0]);
    }

    /**
     * Verifica que la máquina pueda quedar en una configuración dada.
     */
    public void testSpinConfiguration()
    {
        SlotMachine machine = new SlotMachine();

        machine.addWheel(1);
        machine.addWheel(2);

        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");

        String[] configuration = {"green", "blue"};

        machine.spin(configuration);

        String[] result = machine.configuration();

        assertEquals("green", result[0]);
        assertEquals("blue", result[1]);
    }
    
    /**
     * Verifica que intercambiar una rueda inexistente
     * no rompa la máquina.
     */
    public void testInvalidSwap()
    {
        SlotMachine machine = new SlotMachine();
    
        machine.addWheel(1);
    
        machine.swap(999, 1);
    
        assertFalse(machine.ok());
    }
    
    /**
     * Verifica que eliminar una rueda inexistente
     * no elimine una rueda válida.
     */
    public void testInvalidDelWheel()
    {
        SlotMachine machine = new SlotMachine();
    
        machine.addWheel(1);
        machine.addWheel(2);
    
        machine.delWheel(999);
    
        assertFalse(machine.ok());
        assertEquals(2, machine.configuration().length);
    }
    
}